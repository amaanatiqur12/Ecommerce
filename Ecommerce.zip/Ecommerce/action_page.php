<?php
		session_start();
		if(isset($_SESSION['same_email'])){
			session_regenerate_id(true);
			unset($_SESSION['same_email']);
		}
		if(isset($_SESSION['same_phone'])){
			session_regenerate_id(true);
			unset($_SESSION['same_phone']);
		}
		// create table registration (first_name varchar(20),last_name varchar(20),country varchar(20),Email varchar(20),password1 varchar(20),confirm_password varchar(20),phone_number varchar(20),verify varchar(20),status1 varchar(20));
		require 'connection.php';	
		$First_Name = $conn->real_escape_string(strip_tags(trim($_REQUEST['First_Name'])));
		$Last_Name = $conn->real_escape_string(strip_tags(trim($_REQUEST['Last_Name'])));
		$Country = $conn->real_escape_string(strip_tags(trim($_REQUEST['Country'])));
		$Email = $conn->real_escape_string(strip_tags(trim($_REQUEST['Email'])));
		$Password = $conn->real_escape_string(strip_tags(trim($_REQUEST['Password'])));
		$Confirm_Password = $conn->real_escape_string(strip_tags(trim($_REQUEST['Confirm_Password'])));
		$Phone_Number = $conn->real_escape_string(strip_tags(trim($_REQUEST['Phone_Number'])));
		$Radio = $conn->real_escape_string(strip_tags(trim($_REQUEST['Radio'])));
		$address = $conn->real_escape_string(strip_tags(trim($_REQUEST['address'])));
		$status1=1;	
		
		$str = "select password1 from registration where Email='$Email' ";
		$result = $conn->query($str) or die($conn->error);
		$ans1 = $result->fetch_array(MYSQLI_ASSOC);
		
		if(isset($ans1['password1']))
		{

			$_SESSION['same_email'] = 5;
			print_r($ans);
			header("location:registration.php");
		}
		$str = "select password1 from registration where phone_number='$Phone_Number'";
		$result = $conn->query($str) or die($conn->error);
		$ans2 = $result->fetch_array(MYSQLI_ASSOC);
		
		if(isset($ans2['password1'])&&!isset($ans1['password1']))
		{
			$_SESSION['same_phone'] = 5;
			print_r($ans);
			header("location:registration.php");
		}
		$str = "insert into registration (first_name,last_name,country,Email,password1,confirm_password,phone_number,verify,status1)  values ('$First_Name','$Last_Name','$Country','$Email','$Password','$Confirm_Password','$Phone_Number','$Radio','$status1')";
		$result = $conn->query($str) or die($conn->error);
		// echo $str;
		if(!isset($ans1['password1'])&&!isset($ans2['password1']))
		 {
			 $str = "insert into registration (first_name,last_name,country,Email,password1,confirm_password,phone_number,verify,status1,address)  values ('$First_Name','$Last_Name','$Country','$Email','$Password','$Confirm_Password','$Phone_Number','$Radio','$status1','$address')";
			 $result = $conn->query($str) or die($conn->error);
			 $str="create table`{$Phone_Number}_cookies` (j_for_select varchar(20),k_for_product varchar(20),id int auto_increment primary key);";
			$result = $conn->query($str) or die($conn->error);
		
			 //header("location:sms_api.php?phone_number=$Phone_Number");
		 	header("location:login.php");
		}
	
		// 


		// header("location:sms_api.php");
		
	      //$con =$_REQUEST['Phone_Number'];
	      
	    //
	     // echo $con;
	     //header("location:sms_api.php?variable_name=$con");	
?>

<!-- <script type="text/javascript">

function formAutoSubmit () {

var frm = document.getElementById("YourFormID");

frm.submit();

}

window.onload = formAutoSubmit;

</script> -->