<?php
	require 'connection.php';
	session_start();
	ob_start();	
?>
<?php
	session_regenerate_id(true);
	unset($_SESSION['j_for_select']);
	session_regenerate_id(true);
	unset($_SESSION['k_for_product']);
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="layout1.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>
	<?php
	if(isset($_COOKIE['id_admin']))
	{
     	include("header_admin.php");
     }
     elseif (isset($_COOKIE['id'])) {   		
     	include("header.php");
     }
       else{
     	include("header.php");
     }
     ?>
		<?php
			$name=$conn->real_escape_string(strip_tags(trim($_POST['search'])));
			
			if($name==''&&!isset($_COOKIE['id_admin']))
			{
				header('location:index.php');
			}
			if($name==''&&isset($_COOKIE['id_admin']))
			{
				header('location:index_admin.php');
			}
			
			$number=strlen($name);

			$str='select * from search';

			$result = $conn->query($str) or die($conn->error);
			$h=0;
			if($result->num_rows > 0){
				while($data = $result->fetch_array(MYSQLI_ASSOC)) 
				{
					$name_search=$data['name'];
					$name_search=substr($name_search,0,$number);
		if(strtolower($name_search) == strtolower($name))
				{
				$h++;		 
			// echo $h;
			$j = $data['j'];
			$k=$data['k'];
			if($j==1)
			{
				$str1 = "select * from bestsellers where id='$k'";	
			}
			elseif($j==2){
				$str1 = "select * from newreleases where id='$k'";
			}
			elseif($j==3)
			{
				$str1 = "select * from hp where id='$k'";
			}
			elseif ($j==4) {
				$str1 = "select * from dell where id='$k'";
			}
			elseif($j==5){
				$str1 = "select * from microsoft where id='$k'";
			}
			elseif($j==6){
				$str1 = "select * from apple where id='$k'";
			}
			elseif($j==7){
				$str1 = "select * from lenovo where id='$k'";
			}
			elseif($j==8){
				$str1 = "select * from index_page where id='$k'";	
			}
			elseif ($j==9) {
				$str1 = "select * from components where id='$k'";
			}
			elseif($j==10){
				$str1 = "select * from bags where id='$k'";
			}
			elseif($j==11){
				$str1 = "select * from networkcomponents where id='$k'";
			}

			

			$result1 = $conn->query($str1) or die($conn->error);	
			// print_r($result);
			if($result1->num_rows > 0){
				while($data1 = $result1->fetch_array(MYSQLI_ASSOC)) 
				{

					
					$photo=$data1['image'];
					$price=$data1['price'];
					$Name=$data1['name'];
					$id=$data1['id'];
					$r=3;
				$u=0;
				while($data1['detail'.$r]!=null)
				{
					$u++;
					$r++;
				}	
					$p=0;
					//$data = $_GET['href'];
					 if(isset($_COOKIE["id_admin"]))
			 		{



			 		
					echo "<div style='margin-left: 8%;margin-top: 6%;width: 100%;float:left'>
						 <div style='float: left;width:25%'>
							<img src='img/$photo'>
						</div>
						<div style='width:100%'>
						<div style='float:left'>
						<a href='product_view_admin.php?id_index=$j&k=$k' style='text-decoration: none;float:left;margin-left:10%'>$Name</a></div>";
						echo "<div style='float: left;margin-left:15%'>
							<p style='font-size: 26px;margin-left: 36%'><span>&#8377;</span>$price</p>
							
						</div>
						<form action='delete_seach_product.php?id=$id&j=$j' method='post'>
							<button style='margin-left:5%;background-color:white;border:0px' class='btn_hover'>
							<i class='fa fa-times' style='margin-left:5%'></i>
							</button>
						</form>
						</div><br>";	
						echo "<ul style='margin-left:30%;margin-top:3%;'>";
						$h=0;
						$r=3;
						while($h<=$u-1)
						{
							$detail=$data1['detail'.$r];
							echo "<li style='margin-top:1%'>$detail</li>";
							$h++;
							$r++;
						}
						echo	"</ul></div></div>";
					
			 		}



			 		
			 		else
			 		{
					//echo $data;
					
					echo "<div style='margin-left: 8%;margin-top: 6%;width: 100%;float:left'>
						 <div style='float: left;width:25%'>
							<img src='img/$photo'>
						</div>
						<div style='width:100%'>
						<div style='float:left'>
						<a href='product_view.php?id_index=$j&k=$k' style='text-decoration: none;float:left;margin-left:10%'>$Name</a>
						</div>
						<div style='float: left;margin-left: 15%'>
							<p style='font-size: 26px;'><span>&#8377;</span>$price</p>
						</div><br>";
						echo "<ul style='margin-left:30%;margin-top:3%;'>";
						$h=0;
						$r=3;
						while($h<=$u-1)
						{
							$detail=$data1['detail'.$r];
							echo "<li style='margin-top:1%'>$detail</li>";
							$h++;
							$r++;
						}

						echo	"</ul></div></div>";
						
					
				}
				}
				}
				

					}

				}
			}
			// echo $h;
			if($h<=0)
			{
				echo "<p style='margin-top:11%;margin-left:14%;font-size:32px'>No result for => ".$name."</p>";
			}

		?>
	<div style='margin-bottom: 12% !important;width: 100%;float: left;'></div>

		<style type="text/css">
					.btn_hover:hover{
						cursor: pointer;
					}
		</style>
</body>
</html>