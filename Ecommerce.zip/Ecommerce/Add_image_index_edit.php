<?php
	    session_start();
		require 'connection.php';
		$img=$_FILES['file']["name"];
		move_uploaded_file($_FILES['file']["tmp_name"],
      			"img/" . $_FILES['file']["name"]);

		$name = $conn->real_escape_string(strip_tags(trim($_REQUEST['name'])));
		$price = $conn->real_escape_string(strip_tags(trim($_REQUEST['price'])));
		
		
				
		$k=$_COOKIE['id_select'];
		

		$count=$_GET['count'];
		$str="update index_page set name='$name',price='$price',image='$img'  where id='$k'";
		$result = $conn->query($str) or die($conn->error);
		$i=3;
		while($i<=$count)
		{
			$detail='detail'.$i;
			$detail = $conn->real_escape_string(strip_tags(trim($_REQUEST[$detail])));
			$str="update index_page set `detail{$i}`='$detail'  where id='$k'";
			$result = $conn->query($str) or die($conn->error);
			$i++;
			
			
		}
	
		

		$str="drop table `8{$k}`";
		$result=$conn->query($str) or die($conn->error);
		
		$str="DELETE FROM search WHERE j='8' and k='$k'";
		$result=$conn->query($str) or die($conn->error);

		$str= "insert into search(name,j,k) values ('$name',8,'$k')";
		$result = $conn->query($str) or die($conn->error);
		
			$str="create table `8{$k}`(comment varchar(100),date varchar(20),id varchar(20))";
			$result=$conn->query($str) or die($conn->error);
		
		
	     header("location:index_admin.php");	
?>

