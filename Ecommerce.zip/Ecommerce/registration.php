<?php
   session_start();
   if(isset($_SESSION['same_email'])){
      $i=8;
      
   }
  
   if(isset($_SESSION['same_phone'])){
      $i=7;
     
   }
  
   require('connection.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="layout1.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>
		
		<div style="width: 100%;height:90px;background-color:#1a1a1a" >
         <button style="float: left;height:0%;width: 9%;border: 0px solid;margin-left: 45%;margin-top: 1.5%;"class="btn_home" onClick="window.location='index.php';">
            <img src="img/zara1.jpg" style="width: 50%">
         </button>
      </div>
		<div>
			<p style="font-size: 26px;float: left;margin-top: 1.5%;margin-left: 16%">Create Id</p>
			<a href="#" style="float: right;text-decoration: none;margin-right: 16%;margin-top: 1.5%;color: #0070c9">FAQ</a>
			<p style="float: right;text-decoration: none;margin-right:1.1%;margin-top: 1.5%">Create a Account</p>
			<a href="login.php" style="float: right;text-decoration: none;margin-right: 1.1%;margin-top: 1.5%;color: #0070c9">Sign In</a>
		</div>
		<div style="width: 100%;height:170px;margin-top:4.4%">
			<img src="img/w_r.png" style="width: 100%;background: black;height:170px">
		</div>
		<div style="margin-top: 1.8%;">
			
		</div>
		<h1 style="margin-left: 41%">Create a Account</h1>
		
<form method="post" class="form" enctype="multipart/form-data" action="action_page.php" style="margin-bottom: 17%">
   <div style="margin-top: 5%">
      <div style="float: left;margin-left: 34%;margin-top: 0.8%;width: 17%;">
            <input type="txt" style="padding-top: 6.3% !important;padding-bottom: 6.3% !important;padding-left: 5% !important;padding-right: 4% !important;font-size: 20px;width: 90%;border-radius: 4px;border: 1px solid " placeholder="First name" name="First_Name" class="First_Name">
            <br>
            <ul class="First_Name_check" style="  list-style-type: none;font-size: 12px;margin-left: 0%;color: red;margin-top: 4%"></ul>
      </div>
      <div style="float: left;margin-left: 1.4%;margin-top: 0.8%;width: 17%">
		    <input type="txt" style="padding-top: 6.3%;padding-bottom: 6.3%;padding-left: 5%;padding-right: 4%;font-size: 20px;width: 90%;border-radius: 4px;border:1px solid" placeholder="Last name" name="Last_Name" class="Last_Name">
          <br>
          <ul class="last_name_check" style="  list-style-type: none;font-size: 12px;color: red;margin-top: 4%"></ul>
	  </div>
   </div>
        
  
		<br>
		<div style="margin-top:7%;margin-left: 34%;">
		<p style="color: #666;font-size: 14px">COUNTRY / REGION</p>
		<select id="country" name="Country" style="padding-top:2%;padding-bottom: 2%;padding-left: 2%;margin-top: 2%;font-size: 22px;padding-right: 16%" name="country_name">
   <option value="Afganistan">Afghanistan</option>
   <option value="Albania">Albania</option>
   <option value="Algeria">Algeria</option>
   <option value="American Samoa">American Samoa</option>
   <option value="Andorra">Andorra</option>
   <option value="Angola">Angola</option>
   <option value="Anguilla">Anguilla</option>
   <option value="Antigua & Barbuda">Antigua & Barbuda</option>
   <option value="Argentina">Argentina</option>
   <option value="Armenia">Armenia</option>
   <option value="Aruba">Aruba</option>
   <option value="Australia">Australia</option>
   <option value="Austria">Austria</option>
   <option value="Azerbaijan">Azerbaijan</option>
   <option value="Bahamas">Bahamas</option>
   <option value="Bahrain">Bahrain</option>
   <option value="Bangladesh">Bangladesh</option>
   <option value="Barbados">Barbados</option>
   <option value="Belarus">Belarus</option>
   <option value="Belgium">Belgium</option>
   <option value="Belize">Belize</option>
   <option value="Benin">Benin</option>
   <option value="Bermuda">Bermuda</option>
   <option value="Bhutan">Bhutan</option>
   <option value="Bolivia">Bolivia</option>
   <option value="Bonaire">Bonaire</option>
   <option value="Bosnia & Herzegovina">Bosnia & Herzegovina</option>
   <option value="Botswana">Botswana</option>
   <option value="Brazil">Brazil</option>
   <option value="British Indian Ocean Ter">British Indian Ocean Ter</option>
   <option value="Brunei">Brunei</option>
   <option value="Bulgaria">Bulgaria</option>
   <option value="Burkina Faso">Burkina Faso</option>
   <option value="Burundi">Burundi</option>
   <option value="Cambodia">Cambodia</option>
   <option value="Cameroon">Cameroon</option>
   <option value="Canada">Canada</option>
   <option value="Canary Islands">Canary Islands</option>
   <option value="Cape Verde">Cape Verde</option>
   <option value="Cayman Islands">Cayman Islands</option>
   <option value="Central African Republic">Central African Republic</option>
   <option value="Chad">Chad</option>
   <option value="Channel Islands">Channel Islands</option>
   <option value="Chile">Chile</option>
   <option value="China">China</option>
   <option value="Christmas Island">Christmas Island</option>
   <option value="Cocos Island">Cocos Island</option>
   <option value="Colombia">Colombia</option>
   <option value="Comoros">Comoros</option>
   <option value="Congo">Congo</option>
   <option value="Cook Islands">Cook Islands</option>
   <option value="Costa Rica">Costa Rica</option>
   <option value="Cote DIvoire">Cote DIvoire</option>
   <option value="Croatia">Croatia</option>
   <option value="Cuba">Cuba</option>
   <option value="Curaco">Curacao</option>
   <option value="Cyprus">Cyprus</option>
   <option value="Czech Republic">Czech Republic</option>
   <option value="Denmark">Denmark</option>
   <option value="Djibouti">Djibouti</option>
   <option value="Dominica">Dominica</option>
   <option value="Dominican Republic">Dominican Republic</option>
   <option value="East Timor">East Timor</option>
   <option value="Ecuador">Ecuador</option>
   <option value="Egypt">Egypt</option>
   <option value="El Salvador">El Salvador</option>
   <option value="Equatorial Guinea">Equatorial Guinea</option>
   <option value="Eritrea">Eritrea</option>
   <option value="Estonia">Estonia</option>
   <option value="Ethiopia">Ethiopia</option>
   <option value="Falkland Islands">Falkland Islands</option>
   <option value="Faroe Islands">Faroe Islands</option>
   <option value="Fiji">Fiji</option>
   <option value="Finland">Finland</option>
   <option value="France">France</option>
   <option value="French Guiana">French Guiana</option>
   <option value="French Polynesia">French Polynesia</option>
   <option value="French Southern Ter">French Southern Ter</option>
   <option value="Gabon">Gabon</option>
   <option value="Gambia">Gambia</option>
   <option value="Georgia">Georgia</option>
   <option value="Germany">Germany</option>
   <option value="Ghana">Ghana</option>
   <option value="Gibraltar">Gibraltar</option>
   <option value="Great Britain">Great Britain</option>
   <option value="Greece">Greece</option>
   <option value="Greenland">Greenland</option>
   <option value="Grenada">Grenada</option>
   <option value="Guadeloupe">Guadeloupe</option>
   <option value="Guam">Guam</option>
   <option value="Guatemala">Guatemala</option>
   <option value="Guinea">Guinea</option>
   <option value="Guyana">Guyana</option>
   <option value="Haiti">Haiti</option>
   <option value="Hawaii">Hawaii</option>
   <option value="Honduras">Honduras</option>
   <option value="Hong Kong">Hong Kong</option>
   <option value="Hungary">Hungary</option>
   <option value="Iceland">Iceland</option>
   <option value="Indonesia">Indonesia</option>
   <option value="India" selected="selected">India</option>
   <option value="Iran">Iran</option>
   <option value="Iraq">Iraq</option>
   <option value="Ireland">Ireland</option>
   <option value="Isle of Man">Isle of Man</option>
   <option value="Israel">Israel</option>
   <option value="Italy">Italy</option>
   <option value="Jamaica">Jamaica</option>
   <option value="Japan">Japan</option>
   <option value="Jordan">Jordan</option>
   <option value="Kazakhstan">Kazakhstan</option>
   <option value="Kenya">Kenya</option>
   <option value="Kiribati">Kiribati</option>
   <option value="Korea North">Korea North</option>
   <option value="Korea Sout">Korea South</option>
   <option value="Kuwait">Kuwait</option>
   <option value="Kyrgyzstan">Kyrgyzstan</option>
   <option value="Laos">Laos</option>
   <option value="Latvia">Latvia</option>
   <option value="Lebanon">Lebanon</option>
   <option value="Lesotho">Lesotho</option>
   <option value="Liberia">Liberia</option>
   <option value="Libya">Libya</option>
   <option value="Liechtenstein">Liechtenstein</option>
   <option value="Lithuania">Lithuania</option>
   <option value="Luxembourg">Luxembourg</option>
   <option value="Macau">Macau</option>
   <option value="Macedonia">Macedonia</option>
   <option value="Madagascar">Madagascar</option>
   <option value="Malaysia">Malaysia</option>
   <option value="Malawi">Malawi</option>
   <option value="Maldives">Maldives</option>
   <option value="Mali">Mali</option>
   <option value="Malta">Malta</option>
   <option value="Marshall Islands">Marshall Islands</option>
   <option value="Martinique">Martinique</option>
   <option value="Mauritania">Mauritania</option>
   <option value="Mauritius">Mauritius</option>
   <option value="Mayotte">Mayotte</option>
   <option value="Mexico">Mexico</option>
   <option value="Midway Islands">Midway Islands</option>
   <option value="Moldova">Moldova</option>
   <option value="Monaco">Monaco</option>
   <option value="Mongolia">Mongolia</option>
   <option value="Montserrat">Montserrat</option>
   <option value="Morocco">Morocco</option>
   <option value="Mozambique">Mozambique</option>
   <option value="Myanmar">Myanmar</option>
   <option value="Nambia">Nambia</option>
   <option value="Nauru">Nauru</option>
   <option value="Nepal">Nepal</option>
   <option value="Netherland Antilles">Netherland Antilles</option>
   <option value="Netherlands">Netherlands (Holland, Europe)</option>
   <option value="Nevis">Nevis</option>
   <option value="New Caledonia">New Caledonia</option>
   <option value="New Zealand">New Zealand</option>
   <option value="Nicaragua">Nicaragua</option>
   <option value="Niger">Niger</option>
   <option value="Nigeria">Nigeria</option>
   <option value="Niue">Niue</option>
   <option value="Norfolk Island">Norfolk Island</option>
   <option value="Norway">Norway</option>
   <option value="Oman">Oman</option>
   <option value="Pakistan">Pakistan</option>
   <option value="Palau Island">Palau Island</option>
   <option value="Palestine">Palestine</option>
   <option value="Panama">Panama</option>
   <option value="Papua New Guinea">Papua New Guinea</option>
   <option value="Paraguay">Paraguay</option>
   <option value="Peru">Peru</option>
   <option value="Phillipines">Philippines</option>
   <option value="Pitcairn Island">Pitcairn Island</option>
   <option value="Poland">Poland</option>
   <option value="Portugal">Portugal</option>
   <option value="Puerto Rico">Puerto Rico</option>
   <option value="Qatar">Qatar</option>
   <option value="Republic of Montenegro">Republic of Montenegro</option>
   <option value="Republic of Serbia">Republic of Serbia</option>
   <option value="Reunion">Reunion</option>
   <option value="Romania">Romania</option>
   <option value="Russia">Russia</option>
   <option value="Rwanda">Rwanda</option>
   <option value="St Barthelemy">St Barthelemy</option>
   <option value="St Eustatius">St Eustatius</option>
   <option value="St Helena">St Helena</option>
   <option value="St Kitts-Nevis">St Kitts-Nevis</option>
   <option value="St Lucia">St Lucia</option>
   <option value="St Maarten">St Maarten</option>
   <option value="St Pierre & Miquelon">St Pierre & Miquelon</option>
   <option value="St Vincent & Grenadines">St Vincent & Grenadines</option>
   <option value="Saipan">Saipan</option>
   <option value="Samoa">Samoa</option>
   <option value="Samoa American">Samoa American</option>
   <option value="San Marino">San Marino</option>
   <option value="Sao Tome & Principe">Sao Tome & Principe</option>
   <option value="Saudi Arabia">Saudi Arabia</option>
   <option value="Senegal">Senegal</option>
   <option value="Seychelles">Seychelles</option>
   <option value="Sierra Leone">Sierra Leone</option>
   <option value="Singapore">Singapore</option>
   <option value="Slovakia">Slovakia</option>
   <option value="Slovenia">Slovenia</option>
   <option value="Solomon Islands">Solomon Islands</option>
   <option value="Somalia">Somalia</option>
   <option value="South Africa">South Africa</option>
   <option value="Spain">Spain</option>
   <option value="Sri Lanka">Sri Lanka</option>
   <option value="Sudan">Sudan</option>
   <option value="Suriname">Suriname</option>
   <option value="Swaziland">Swaziland</option>
   <option value="Sweden">Sweden</option>
   <option value="Switzerland">Switzerland</option>
   <option value="Syria">Syria</option>
   <option value="Tahiti">Tahiti</option>
   <option value="Taiwan">Taiwan</option>
   <option value="Tajikistan">Tajikistan</option>
   <option value="Tanzania">Tanzania</option>
   <option value="Thailand">Thailand</option>
   <option value="Togo">Togo</option>
   <option value="Tokelau">Tokelau</option>
   <option value="Tonga">Tonga</option>
   <option value="Trinidad & Tobago">Trinidad & Tobago</option>
   <option value="Tunisia">Tunisia</option>
   <option value="Turkey">Turkey</option>
   <option value="Turkmenistan">Turkmenistan</option>
   <option value="Turks & Caicos Is">Turks & Caicos Is</option>
   <option value="Tuvalu">Tuvalu</option>
   <option value="Uganda">Uganda</option>
   <option value="United Kingdom">United Kingdom</option>
   <option value="Ukraine">Ukraine</option>
   <option value="United Arab Erimates">United Arab Emirates</option>
   <option value="United States of America">United States of America</option>
   <option value="Uraguay">Uruguay</option>
   <option value="Uzbekistan">Uzbekistan</option>
   <option value="Vanuatu">Vanuatu</option>
   <option value="Vatican City State">Vatican City State</option>
   <option value="Venezuela">Venezuela</option>
   <option value="Vietnam">Vietnam</option>
   <option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
   <option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
   <option value="Wake Island">Wake Island</option>
   <option value="Wallis & Futana Is">Wallis & Futana Is</option>
   <option value="Yemen">Yemen</option>
   <option value="Zaire">Zaire</option>
   <option value="Zambia">Zambia</option>
   <option value="Zimbabwe">Zimbabwe</option>
</select>
			
		</div>
      
		 <hr style="margin-top: 3%;width: 81%;margin-left: 10%">
		<div style="margin-top: 3%;margin-left: 34%;">
			<!-- <input type="txt" style="margin-top: 1%;width: 52.2%;padding-top:1%;padding-bottom: 1%;font-size: 20px;padding-left: 1%;padding-right: 1%;border-radius: 2px;border:1px solid" placeholder="Email" name="Email" class="Email">
         <ul class="Email_check" style="  list-style-type: none;font-size: 12px;color: red;margin-top: 1%"></ul> -->
         <?php
         if(!isset($i))
         {
            $i=0;
         }
          if($i==8)
          {
            echo "<input type='txt' style='margin-top: 1%;width: 52.2%;padding-top:1%;padding-bottom: 1%;font-size: 20px;padding-left: 1%;padding-right: 1%;border-radius: 2px;border:1px solid' placeholder='Email' name='Email' class='Email error'><ul class='Email_check' style='list-style-type: none;font-size: 12px;color: red;margin-top: 1%'><li><i class='fa fa-exclamation-circle' style='margin-right:0.4%'></i>Email exist</li></ul>";
          }
          else
          {
            echo "<input type='txt' style='margin-top: 1%;width: 52.2%;padding-top:1%;padding-bottom: 1%;font-size: 20px;padding-left: 1%;padding-right: 1%;border-radius: 2px;border:1px solid' placeholder='Email' name='Email' class='Email'><ul class='Email_check' style='list-style-type: none;font-size: 12px;color: red;margin-top: 1%'></ul>";
          }
     
         ?>
			<input type="password" style="margin-top: 3%;width: 52.2%;padding-top:1%;padding-bottom: 1%;font-size: 20px;padding-left: 1%;padding-right: 1%;border-radius: 2px;border:1px solid" placeholder="Password" name="Password" class="Password">
         <ul class="Password_li" style="  list-style-type: none;font-size: 12px;color: red;margin-top: 1%"></ul>
			<input type="password" style="margin-top: 3%;width: 52.2%;padding-top:1%;padding-bottom: 1%;font-size: 20px;padding-left: 1%;padding-right: 1%;border-radius: 2px;border:1px solid" placeholder="Confirm password " name="Confirm_Password" class="Confirm_Password">
         <ul class="Confirm_Password_li " style="  list-style-type: none;font-size: 12px;color: red;margin-top: 1%"></ul>
		</div>
		<hr style="margin-top: 3%;width: 81%;margin-left: 10%">
      <div style="margin-top: 3%;margin-left: 34%;">
            <textarea rows="4" cols="37" placeholder="Address..." style="font-size: 22px;padding: 5px 10px;" class="address" name="address"></textarea>
            <ul class="address_li" style="  list-style-type: none;font-size: 12px;color: red;margin-top: 1%"></ul>
       </div>
		<div style="margin-top: 3%;margin-left: 34%;">
         <?php
         if($i==7)
         {
   		   echo   '<input type="txt" style="margin-top: 1%;width: 52.2%;padding-top:1%;padding-bottom: 1%;font-size: 20px;padding-left: 1%;padding-right: 1%;border-radius: 2px;border:1px solid" placeholder="Phone number" name="Phone_Number" class="Phone_Number error">
         <ul class="Contact_check " style="  list-style-type: none;font-size: 12px;color: red;margin-top: 1%"><li><i class="fa fa-exclamation-circle" style="margin-right:2%"></i>Phone number already exist</li></ul>';
         
         }
         else
         {
           echo   '<input type="txt" style="margin-top: 1%;width: 52.2%;padding-top:1%;padding-bottom: 1%;font-size: 20px;padding-left: 1%;padding-right: 1%;border-radius: 2px;border:1px solid" placeholder="Phone number" name="Phone_Number" class="Phone_Number">
         <ul class="Contact_check " style="  list-style-type: none;font-size: 12px;color: red;margin-top: 1%"></ul>';
          
         }
         ?>
		<!-- 	<p style="color: #666;margin-top: 2%;font-size: 14px">Make sure you enter a phone number you can always access. It <br>will be used to verify your identity any time you sign in on a new <br>device or web browser. Messaging or data rates may apply.</p> -->
			<p style="margin-top: 2%;float: left;">Verify with a:</p>
			<input type="radio" name="Radio" style="float: left;margin-top: 2%;margin-left: 1.4%" checked>
			<p style="float: left;margin-top: 2%;margin-left: 0.5%"> Text message</p>
			<input type="radio" name="Radio" style="float: left;margin-top: 2%;margin-left: 4%" >
        
			<p style="float: left;margin-top: 2%;margin-left: 0.5%">Gmail</p> 
		</div>

		<hr style="margin-top: 5%;width: 81%;margin-left: 10%;margin-bottom: 3%">
		<div style="margin-top: 3%;margin-left: 49%;font-size: 37px">
			<i class="fa fa-handshake" style="color: #06c;"></i>
		</div>
		<!-- <p style="margin-top: 3%;margin-left: 34%;font-size: 14px;color: #666;">Your Apple ID information is used to allow you to sign in securely and access your<br><span style="margin-left: 2.4%"> data. Apple records certain usage data for security, support and reporting<br></span> <span style="margin-left:13%">purposes.<a href="#" style="text-decoration: none;color: #06c;"> See how your data is managed.</a></span></p> -->
	      <button style="width: 13%;height: 20px;margin-left: 44.5%;margin-top: 3%;padding-bottom: 2.4%;padding-top: 1%;background: linear-gradient(#42a1ec,#0070c9);border:1px solid;border-radius: 5px;color: white;font-size: 19px" class="Continue">Continue</button>
</form>
		<!-- <div style="width: 100%;background-color: #C5C6C6;height: 90px;margin-top: 8%;background-color: #f5f5f7;">
			<p style="color: #86868b;font-size: 13px;margin-left: 14%;padding-top: 1.6%"><span><a href="#" style="text-decoration:none;color: #06c;margin-left: 0.5%;font-size: 13px">Find a retailer</a></span><span style="margin-left: 0.6%;font-size: 13px">near you.</span></p>
			<p style="margin-left: 14.3%;font-size: 13px;color: #86868b;margin-top: 0.5%;"><span style="float: left;">Copyright © 2020 Apple Inc. All rights reserved.</span><a href="#" style="text-decoration: none;float: left;color: #86868b;font-size: 13px;color: #515154;margin-left: 3%">Privacy Policy</a> <div style="border-left: 1px solid;height: 15px;float: left;color: #86868b;margin-left: 1%"></div><a href="#" style="text-decoration: none;float: left;color: #515154;font-size: 13px;margin-left: 1%">Terms of Use</a>
			<div  style="border-left: 1px solid;color: #86868b;height: 15px;float: left;margin-left: 1%"></div><a href="#" style="text-decoration: none;float: left;color: #515154;font-size: 13px;margin-left: 1%">Legal </a><div  style="color: #86868b;border-left: 1px solid;height: 15px;float: left;margin-left: 1%"></div><a href="#" style="text-decoration: none;color: #515154;font-size: 13px;margin-left: 1%">Site Map</a></p>
		</div>  -->
      <style type="text/css">
         .error{
            border:1px solid red !important;
         }
      </style>
     
     
      <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.0.min.js"></script>
      <script type="text/javascript">
     
         
         $('.form').on('submit', function() {
            First_Name_input=$(".First_Name").val();
            First_Name_varaible=/^[a-zA-Z\.\ ][a-zA-Z\.\ ]([a-zA-Z\.\ ]+)?[a-zA-Z\.\ ]$/
            First_Name_check=First_Name_varaible.test(First_Name_input);
            // console.log(Name_check)
            i=0
            if(First_Name_check==false)
            {
               
               i=1;
               $(".First_Name").addClass("error")
               str=`<li><h1 style="font-size:12px;font-family: arial;"><i class="fa fa-exclamation-circle" style="margin-right:2%"></i>Enter your First Name</h1></li>`;
               $(".First_Name_check").empty();
               $(".First_Name_check").append(str);
            }
            else
            {
               $(".First_Name").removeClass("error")  
               $(".First_Name_check").empty();     
            }
            $(".First_Name").keyup(function(){
                  $(".First_Name").removeClass("error") 
                  $(".First_Name_check").empty();    
            });

             last_name_input=$(".Last_Name").val();
            Last_name_varaible=/^[a-zA-Z\.][a-zA-Z\.]([a-zA-Z\.]+)?[a-zA-Z\.]$/
            last_name_check=Last_name_varaible.test( last_name_input);
            t=0
            if(last_name_check==false)
            {
               
               t=1;
               $(".Last_Name").addClass("error")
               str=`<li><i class="fa fa-exclamation-circle" style="margin-right:2%"></i>Enter your Last Name</li>`;
               $(".last_name_check").empty();
               $(".last_name_check").append(str);
            }
            else
            {
               $(".Last_Name").removeClass("error")  
               $(".last_name_check").empty;     
            }
              $(".Last_Name").keyup(function(){
                  $(".Last_Name").removeClass("error") 
                  $(".last_name_check").empty();    
            });
            Email_input=$(".Email").val();
            Email_varaible=/^[a-zA-Z0-9]([a-zA-Z0-9\.]+)?[a-zA-Z0-9]@gmail.com$/
            Email_check=Email_varaible.test(Email_input);
            // console.log(Name_check)
            x=0
            if(Email_check==false)
            {
               
               x=1;
               $(".Email").addClass("error")
               str=`<li><i class="fa fa-exclamation-circle" style="margin-right:0.4%"></i>Enter a valid Email address</li>`;
               $(".Email_check").empty();
               $(".Email_check").append(str);
            }
            else
            {
               $(".Email").removeClass("error") 
               $(".Email_check").empty();    
            }
             $(".Email").keyup(function(){
                  $(".Email").removeClass("error") 
                  $(".Email_check").empty();    
            });
             y=0;     
            Password_input=$(".Password").val();
            Password_varaible=/^([a-zA-Z0-9\.\@\&\!]{4,64})$/;
            Password_check=Password_varaible.test(Password_input);
            // console.log(Password_check)
            if(Password_check==false)
            {
               y=1;
               $(".Password").addClass("error")
               str=`<li><i class="fa fa-exclamation-circle" style="margin-right:0.8%"></i>Enter your password</li>`;
               $(".Password_li").empty();
               $(".Password_li").append(str);   
               
            }
            else
            {
               $(".Password").removeClass("error")
               $(".Password_li").empty();
            }
            $(".Password").keyup(function(){
                  $(".Password").removeClass("error") 
                  $(".Password_li").empty();    
            });
            console.log(Password_input)
            console.log(Password_varaible)
            console.log(Password_check)
            e=0;     
            Confirm_Password_input=$(".Confirm_Password").val();
            Confirm_Password_varaible=/^([a-zA-Z0-9\.\@\&\!]{4,64})$/;
            Confirm_Password_check=Confirm_Password_varaible.test(Password_input);
            // console.log(Password_check)
            if(Confirm_Password_check==false)
            {
               e=1;
               $(".Confirm_Password").addClass("error")
               str=`<li> <i class="fa fa-exclamation-circle" style="margin-right:0.8%"></i>Confirm your password.</li>`;
               $(".Confirm_Password_li").empty();
               $(".Confirm_Password_li").append(str);                 
            }
            else if(Confirm_Password_input!=Password_input)
            {
               e=1;
               $(".Confirm_Password").addClass("error")
               str=`<li> <i class="fa fa-exclamation-circle" style="margin-right:0.8%"></i> The passwords you entered do not match.</li>`;
               $(".Confirm_Password_li").empty();
               $(".Confirm_Password_li").append(str);     
            }
            else if(Confirm_Password_check==Password_check) 
            {
               $(".Confirm_Password").removeClass("error")
               $(".Confirm_Password_li").empty();
            }
            $(".Confirm_Password").keyup(function(){
                  $(".Confirm_Password").removeClass("error") 
                  $(".Confirm_Password_li").empty();    
            });
            Contact_input=$(".Phone_Number").val()
            Contact_number=/^([0-9]{10})$/;
            Contact_check=Contact_number.test(Contact_input);
            console.log(Contact_check)
            console.log(Contact_input)
            console.log(Contact_number)

            v=0
            if(Contact_check==false)
            {
                  v=1;
                  str=`<li>  <i class="fa fa-exclamation-circle" style="margin-right:0.8%"></i> Enter a valid phone number.</li>`;
                  $(".Contact_check").empty();
                  $(".Contact_check").append(str);
                  $(".Phone_Number").addClass("error")
               
            }
            else
            {
                  $(".Phone_Number").removeClass("error")
                  $(".Contact_check").empty();           
            }
               $(".Phone_Number").keyup(function(){
                  $(".Phone_Number").removeClass("error") 
                  $(".Contact_check").empty();    
            });
            console.log(e)
            address=$(".address").val();
            console.log(address)
             console.log(1)
            f=0
            if(address=='')
            {
               
               f=1;
               $(".address").addClass("error")
               str=`<li><h1 style="font-size:12px;font-family: arial;"><i class="fa fa-exclamation-circle" style="margin-right:2%"></i>Enter your address</h1></li>`;
               $(".address_li").empty();
               $(".address_li").append(str);
            }
            else
            {
               $(".address").removeClass("error")  
               $(".address_li").empty();     
            }
            $(".address").keyup(function(){
                  $(".address").removeClass("error") 
                  $(".address_li").empty();    
            });
             if(i==0&&t==0&&x==0&&y==0&&e==0&&v==0&&f==0)
             {
                  return true 
             }
             else
             {
                  return false
             }
        })

      </script>
</body>
</html>