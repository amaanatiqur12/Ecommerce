<?php
	//print_r($_COOKIE['id']);

if(isset($_COOKIE['id_admin'])){
	setcookie('id_admin',$dbapss,time()-3600000000);
}
 if(isset($_COOKIE['id'])){
	setcookie('id',$dbapss,time()-3600000000);
	session_regenerate_id(true);
	unset($_SESSION['Identity_database']);
}

	
	header("location:login.php");
?>