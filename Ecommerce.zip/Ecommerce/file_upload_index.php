<?php
	require('connection.php');
		// print_r($_FILES);
		// echo "<pre>";
		// print_r($_FILES);
		// echo "</pre>";
		$i=1;
		while($i<=5)
		{ 
			$file="file$i";
			// print_r($_FILES[$file]);
			if($_FILES[$file]['error']!=4)
			{
				//print_r($_FILES[$file]['error']);

				$sql="SELECT image FROM image_index where id='$i'";
				$result = $conn->query($sql) or die($conn->error);
				$data = $result->fetch_array(MYSQLI_ASSOC);
				//print_r($data);
				// unlink('path/to/file.jpg');
				$img=$data['image'];
				//print_r($img);
			 	unlink("img/$img");
				$sql="Update image_index set image=NULL where id='$i'";
				$result = $conn->query($sql) or die($conn->error);
      			move_uploaded_file($_FILES[$file]["tmp_name"],
      			"img/" . $_FILES[$file]["name"]);
      			$img=$_FILES[$file]["name"];
      			// print_r($img);
      			// $sql="insert into image_index (image)  values ('$img') before id=$i"
      			$sql="update image_index set image='$img' where id='$i'";
      			$result = $conn->query($sql) or die($conn->error);
      		}
      		$i++;
     	}
     	
     	
     	
     	// $content1=nl2br($content1);
     	// print_r($content1);
     	$j=1;
     	while($j<=5)
     	{
     		$content="content$j";
     		$content= $conn->real_escape_string(trim($_REQUEST[$content]));
     		if($content!="")
     		{
     			$sql="Update image_index set content=NULL where id='$j'";
				$result = $conn->query($sql) or die($conn->error);
				$sql="update image_index set content='$content' where id='$j'";
      			$result = $conn->query($sql) or die($conn->error);	
     		}
     		$j++;
     	}
     $y=1;
     while($y<=5)
     {
     	$price="price$y";
     	$price= $conn->real_escape_string(strip_tags(trim($_REQUEST[$price])));
     	if($price!="")
     	{
     		$sql="Update image_index set price=NULL where id='$y'";
			$result = $conn->query($sql) or die($conn->error);
			$sql="update image_index set price='$price' where id='$y'";
      		$result = $conn->query($sql) or die($conn->error);
     	}
     	$y++;
     }
     $k=1;
     while($k<=5)
     {
     	$label="label$k";
     	$label= $conn->real_escape_string(strip_tags(trim($_REQUEST[$label])));
     	if($label!="")
     	{
     		$sql="Update image_index set label=NULL where id='$k'";
			$result = $conn->query($sql) or die($conn->error);
			$sql="update image_index set label='$label' where id='$k'";
      		$result = $conn->query($sql) or die($conn->error);
     	}
     	$k++;	
     }
     

      		header("location:index_admin.php");	
?>