<style>


@keyframes background-fade {
    99.9% {
        background:#E1FEE0;
    }
    100% {
        background:#000;
    }
}p {
    display: inline;
    animation: background-fade 10s forwards;
}

</style>

<html>
  <body>
    <p style="background:#E1FEE0;">Human</p>
  </body>
</html>
