<?php
require 'connection.php';	
	$j=$_GET['j'];
	$id=$_GET['id'];
	$str="drop table `$j{$id}`";
	$result=$conn->query($str) or die($conn->error);

	$str="DELETE FROM search WHERE j='$j' and k='$id'";
	$result=$conn->query($str) or die($conn->error);
	
			if($j==1)
			{
				$str = "DELETE FROM bestsellers WHERE id='$id'";
			}
			elseif($j==2)
			{
				$str = "DELETE FROM newreleases WHERE id='$id'";
			}
			elseif($j==3)
			{
				$str = "DELETE FROM hp WHERE id='$id'";
			}
			elseif ($j==4) {
				$str = "DELETE FROM dell WHERE id='$id'";
			}
			elseif($j==5){
				$str = "DELETE FROM Asus WHERE id='$id'";
			}
			elseif($j==6){
				$str = "DELETE FROM apple WHERE id='$id'";
			}
			elseif($j==9){
				$str = "DELETE FROM components WHERE id='$id'";
			}
			elseif($j==10){
				$str = "DELETE FROM bags WHERE id='$id'";
			}
			elseif($j==11){
				$str = "DELETE FROM networkcomponents WHERE id='$id'";
			}
			$result = $conn->query($str) or die($conn->error);
			header("location:search.php?href=$j");	
?>