-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2021 at 05:48 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `66`
--

CREATE TABLE `66` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `66`
--

INSERT INTO `66` (`comment`, `date`, `id`) VALUES
('I am the best', ' 6 March 2021 ', 'Asifmamu'),
('Amaan khan', ' 8 March 2021 ', 'Asifmamu');

-- --------------------------------------------------------

--
-- Table structure for table `81`
--

CREATE TABLE `81` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `81`
--

INSERT INTO `81` (`comment`, `date`, `id`) VALUES
('Amaan khan', ' 6 March 2021 ', 'Asifmamu'),
('Amaan khan', ' 6 March 2021 ', 'Asifmamu');

-- --------------------------------------------------------

--
-- Table structure for table `82`
--

CREATE TABLE `82` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `83`
--

CREATE TABLE `83` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `84`
--

CREATE TABLE `84` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `85`
--

CREATE TABLE `85` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `86`
--

CREATE TABLE `86` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `87`
--

CREATE TABLE `87` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `87`
--

INSERT INTO `87` (`comment`, `date`, `id`) VALUES
('Amaan khan', ' 9 March 2021 ', 'Asifmamu');

-- --------------------------------------------------------

--
-- Table structure for table `88`
--

CREATE TABLE `88` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `88`
--

INSERT INTO `88` (`comment`, `date`, `id`) VALUES
('I am the best', ' 9 March 2021 ', '10');

-- --------------------------------------------------------

--
-- Table structure for table `89`
--

CREATE TABLE `89` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `810`
--

CREATE TABLE `810` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `811`
--

CREATE TABLE `811` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `812`
--

CREATE TABLE `812` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `813`
--

CREATE TABLE `813` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `814`
--

CREATE TABLE `814` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `815`
--

CREATE TABLE `815` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `816`
--

CREATE TABLE `816` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `817`
--

CREATE TABLE `817` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `817`
--

INSERT INTO `817` (`comment`, `date`, `id`) VALUES
('Amaan khan', ' 9 March 2021 ', '10'),
('I am the best', ' 9 March 2021 ', '10');

-- --------------------------------------------------------

--
-- Table structure for table `818`
--

CREATE TABLE `818` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `819`
--

CREATE TABLE `819` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `820`
--

CREATE TABLE `820` (
  `comment` varchar(100) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `8133337361_cookies`
--

CREATE TABLE `8133337361_cookies` (
  `j_for_select` varchar(20) DEFAULT NULL,
  `k_for_product` varchar(20) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `8133337361_cookies`
--

INSERT INTO `8133337361_cookies` (`j_for_select`, `k_for_product`, `id`) VALUES
('8', '17', 2),
('8', '9', 3),
('8', '13', 4),
('8', '19', 5);

-- --------------------------------------------------------

--
-- Table structure for table `8133337361_order`
--

CREATE TABLE `8133337361_order` (
  `j_for_select` varchar(20) DEFAULT NULL,
  `k_for_product` varchar(20) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `8333547361_cookies`
--

CREATE TABLE `8333547361_cookies` (
  `j_for_select` varchar(20) DEFAULT NULL,
  `k_for_product` varchar(20) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `8333547361_cookies`
--

INSERT INTO `8333547361_cookies` (`j_for_select`, `k_for_product`, `id`) VALUES
('8', '17', 18),
('8', '7', 19),
('6', '5', 20);

-- --------------------------------------------------------

--
-- Table structure for table `apple_macbook`
--

CREATE TABLE `apple_macbook` (
  `photo` varchar(100) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `processor` varchar(100) DEFAULT NULL,
  `ram` varchar(100) DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `ssd` varchar(100) DEFAULT NULL,
  `display` varchar(100) DEFAULT NULL,
  `warranty` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `yearofuse` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `apple_macbook`
--

INSERT INTO `apple_macbook` (`photo`, `price`, `processor`, `ram`, `os`, `ssd`, `display`, `warranty`, `name`, `yearofuse`, `id`) VALUES
('hp-15.jpg', '32233223', '10th Gz Intel Core i5-10210U processor, 1.6 GHz base speed, 4.2 GHz max speed, 4 Cores, 8 threads', '8GB memory', 'MacOS 10.12 Sierra', '128GB or 256GB SSD', '14-Inch (1920X 1080 )Full HD Anti-Glare Screen, Intel UHD Graphics', '1 Year manufacturer warranty from the date of purchase for both Laptop and Webcam', 'Mi Notebook 14 Intel Core i5-10210U 10th Gen Thin 14-Inch (1920X 1080 )', '1 year used, no scratch ,with charger', 6);

-- --------------------------------------------------------

--
-- Table structure for table `asus`
--

CREATE TABLE `asus` (
  `photo` varchar(100) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `processor` varchar(100) DEFAULT NULL,
  `ram` varchar(100) DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `ssd` varchar(100) DEFAULT NULL,
  `display` varchar(100) DEFAULT NULL,
  `warranty` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `yearofuse` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `comment1`
--

CREATE TABLE `comment1` (
  `comment1` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comment1`
--

INSERT INTO `comment1` (`comment1`) VALUES
('dsds'),
('dsds'),
('adssad'),
('dsds'),
('sasasd'),
('dsds'),
('dsds'),
('dsds'),
('Amaan khan');

-- --------------------------------------------------------

--
-- Table structure for table `dell`
--

CREATE TABLE `dell` (
  `photo` varchar(100) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `processor` varchar(100) DEFAULT NULL,
  `ram` varchar(100) DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `ssd` varchar(100) DEFAULT NULL,
  `display` varchar(100) DEFAULT NULL,
  `warranty` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `yearofuse` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `hp`
--

CREATE TABLE `hp` (
  `photo` varchar(100) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `processor` varchar(100) DEFAULT NULL,
  `ram` varchar(100) DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `ssd` varchar(100) DEFAULT NULL,
  `display` varchar(100) DEFAULT NULL,
  `warranty` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `yearofuse` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hp`
--

INSERT INTO `hp` (`photo`, `price`, `processor`, `ram`, `os`, `ssd`, `display`, `warranty`, `name`, `yearofuse`, `id`) VALUES
('hp1.jpg', '67655', '1.8GHz dual-core 5th-generation Intel Core i5 with Turbo Boost up to 2.9GHz', '8GB DDR4-2666MHz RAM and  Storage: 256 GB SSD', 'MacOS 10.12 Sierra', '8GB DDR4-2666MHz RAM and  Storage: 256 GB SSD', '15.6-Inch HD Display, 220 nits, 45% NTSC', 'This genuine HP laptop comes with a 1-year domestic warranty from HP', 'Mi Notebook 14 Intel Core i5-10210U 10th Gen Thin 14-Inch (1920X 1080 )', '1 year used, no scratch ,with charger', 1);

-- --------------------------------------------------------

--
-- Table structure for table `index_page`
--

CREATE TABLE `index_page` (
  `name` varchar(100) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `detail3` varchar(100) DEFAULT NULL,
  `detail4` varchar(100) DEFAULT NULL,
  `detail5` varchar(100) DEFAULT NULL,
  `detail6` varchar(100) DEFAULT NULL,
  `detail7` varchar(100) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `detail9` varchar(100) DEFAULT NULL,
  `detail10` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `detail8` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `index_page`
--

INSERT INTO `index_page` (`name`, `price`, `detail3`, `detail4`, `detail5`, `detail6`, `detail7`, `image`, `detail9`, `detail10`, `id`, `detail8`) VALUES
('Apple MacBook Pro 16-inch 9th Gen IntelCore i7', '199900', 'Ninth-generation 6-core Intel Core i7 processor', '16-inch (diagonal) LED-backlit Retina display', '512GB or 1TB SSD', '2.6GHz 6-core 9th-generation Intel Core i7 processor with Turbo Boost up to 4.5GHz or 2.3GHz 8-core ', NULL, 'hp-14.jpg', NULL, NULL, 1, NULL),
('Apple MacBook Pro 16-inch 9th Gen IntelCore i7', '199900', 'Ninth-generation 6-core Intel Core i7 processor', '16-inch (diagonal) LED-backlit Retina display', '512GB or 1TB SSD', '2.6GHz 6-core 9th-generation Intel Core i7 processor with Turbo Boost up to 4.5GHz or 2.3GHz 8-core ', NULL, 'hp-15.jpg', NULL, NULL, 2, NULL),
('Apple MacBook Pro 16-inch 9th Gen IntelCore i7', '199900', 'Ninth-generation 6-core Intel Core i7 processor', '16-inch (diagonal) LED-backlit Retina display', '512GB or 1TB SSD', '2.6GHz 6-core 9th-generation Intel Core i7 processor with Turbo Boost up to 4.5GHz or 2.3GHz 8-core ', NULL, 'hp-16.jpg', NULL, NULL, 3, NULL),
('Apple MacBook Pro 16-inch 9th Gen IntelCore i7', '199900', 'Ninth-generation 6-core Intel Core i7 processor', '16-inch (diagonal) LED-backlit Retina display', '512GB or 1TB SSD', '2.6GHz 6-core 9th-generation Intel Core i7 processor with Turbo Boost up to 4.5GHz or 2.3GHz 8-core ', NULL, 'hp-17.jpg', NULL, NULL, 4, NULL),
('Apple MacBook Pro 16-inch 9th Gen IntelCore i7', '199900', 'Ninth-generation 6-core Intel Core i7 processor', '16-inch (diagonal) LED-backlit Retina display', '512GB or 1TB SSD', '2.6GHz 6-core 9th-generation Intel Core i7 processor with Turbo Boost up to 4.5GHz or 2.3GHz 8-core ', NULL, 'hp-18.jpg', NULL, NULL, 5, NULL),
('Microsoft Surface Pro 7  Intel Core i5 2.3 inch', '78490', '10th Generation Intel Core i5-1035G4', '12.3 inch 2736 x 1824 Pixelsense display | Touchscreen enabled', '8GB LPDDR4x RAM with Intel Iris Plus Graphics | Storage: 128GB SSD', 'This genuine Microsoft Surface laptop comes with 1 year limited hardware warranty from Microsoft cov', NULL, 'microsoftsurfacepro1.jpg', NULL, NULL, 6, NULL),
('Microsoft Surface Pro 7  Intel Core i5 2.3 inch', '78490', 'Ninth-generation 6-core Intel Core i7 processor', '12.3 inch 2736 x 1824 Pixelsense display | Touchscreen enabled', '8GB LPDDR4x RAM with Intel Iris Plus Graphics | Storage: 128GB SSD', 'This genuine Microsoft Surface laptop comes with 1 year limited hardware warranty from Microsoft cov', NULL, 'microsoftsurfacepro2.jpg', NULL, NULL, 7, NULL),
('Microsoft Surface Pro 7  Intel Core i5 2.3 inch', '21211', '10th Generation Intel Core i5-1035G4', '16-inch (diagonal) LED-backlit Retina display', '8GB LPDDR4x RAM with Intel Iris Plus Graphics | Storage: 128GB SSD', 'This genuine Microsoft Surface laptop comes with 1 year limited hardware warranty from Microsoft cov', NULL, 'microsoftsurfacepro3.jpg', NULL, NULL, 8, NULL),
('Microsoft Surface Pro 7  Intel Core i5 2.3 inch', '212131', 'Ninth-generation 6-core Intel Core i7 processor', '12.3 inch 2736 x 1824 Pixelsense display | Touchscreen enabled', '8GB LPDDR4x RAM with Intel Iris Plus Graphics | Storage: 128GB SSD', '2.6GHz 6-core 9th-generation Intel Core i7 processor with Turbo Boost up to 4.5GHz or 2.3GHz 8-core ', NULL, 'microsoftsurfacepro4.jpg', NULL, NULL, 9, NULL),
('Microsoft Surface Pro 7  Intel Core i5 2.3 inch', '12121', 'Ninth-generation 6-core Intel Core i7 processor', '12.3 inch 2736 x 1824 Pixelsense display | Touchscreen enabled', '8GB LPDDR4x RAM with Intel Iris Plus Graphics | Storage: 128GB SSD', 'This genuine Microsoft Surface laptop comes with 1 year limited hardware warranty from Microsoft cov', '256GB SSD/128GB SSD', 'microsoftsurfacepro5.jpg', NULL, NULL, 10, NULL),
('Dell Inspiron 3505 15.6\" FHD Anti Glare Display Laptop', '34794', 'AMD Ryzen 3 3250U Mobile Processor with Radeon Graphics', '8GB RAM | 256 GB M.2 PCIe NVMe Solid State Drive', 'Windows 10 Home Single Language | Microsoft Office Home and Student 2019', '15.6-inch FHD (1920 x 1080) Anti-glare LED Backlight Narrow Border WVA Display', NULL, 'dell1.jpg', NULL, NULL, 11, NULL),
('Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '23221', '10th Generation Intel Core i5-1035G4', '16-inch (diagonal) LED-backlit Retina display', '8GB LPDDR4x RAM with Intel Iris Plus Graphics | Storage: 128GB SSD', '2.6GHz 6-core 9th-generation Intel Core i7 processor with Turbo Boost up to 4.5GHz or 2.3GHz 8-core ', NULL, 'dell2.jpg', NULL, NULL, 12, NULL),
('Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '2321231', 'Ninth-generation 6-core Intel Core i7 processor', '12.3 inch 2736 x 1824 Pixelsense display | Touchscreen enabled', 'Windows 10 Home Single Language | Microsoft Office Home and Student 2019', '2.6GHz 6-core 9th-generation Intel Core i7 processor with Turbo Boost up to 4.5GHz or 2.3GHz 8-core ', NULL, 'dell3.jpg', NULL, NULL, 13, NULL),
('Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '23432', '10th Generation Intel Core i5-1035G4', '35.6 x 23.3 x 1.8 cm; 1.66 Kilograms', 'Windows 10 Home Single Language | Microsoft Office Home and Student 2019', '2.6GHz 6-core 9th-generation Intel Core i7 processor with Turbo Boost up to 4.5GHz or 2.3GHz 8-core ', NULL, 'dell4.jpg', NULL, NULL, 14, NULL),
('Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '42322', 'Ninth-generation 6-core Intel Core i7 processor', '12.3 inch 2736 x 1824 Pixelsense display | Touchscreen enabled', 'Windows 10 Home Single Language | Microsoft Office Home and Student 2019', '2.6GHz 6-core 9th-generation Intel Core i7 processor with Turbo Boost up to 4.5GHz or 2.3GHz 8-core ', NULL, 'dell1.jpg', NULL, NULL, 15, NULL),
('Lenovo IdeaPad Slim 5i 11th Gen Intel Core i5 15.6 1TB HDD+256GB SSD', '71999', 'Core i5', '35.6 x 23.3 x 1.8 cm; 1.66 Kilograms', 'Pre-Loaded Windows 10 Home with Lifetime Validity', '1.79 cm Thin and 1.66 kg Light', NULL, 'lenovo1.jpg', NULL, NULL, 16, NULL),
('Lenovo IdeaPad Slim 5i 11th Gen Intel Core i5 15.6 1TB HDD+256GB SSD', '21212', 'Ninth-generation 6-core Intel Core i7 processor', '35.6 x 23.3 x 1.8 cm; 1.66 Kilograms', '8GB LPDDR4x RAM with Intel Iris Plus Graphics | Storage: 128GB SSD', '1.79 cm Thin and 1.66 kg Light', NULL, 'lenovo2.jpg', NULL, NULL, 17, NULL),
('Lenovo IdeaPad Slim 5i 11th Gen Intel Core i5 15.6 1TB HDD+256GB SSD', '212121', 'Ninth-generation 6-core Intel Core i7 processor', '12.3 inch 2736 x 1824 Pixelsense display | Touchscreen enabled', '512GB or 1TB SSD', '2.6GHz 6-core 9th-generation Intel Core i7 processor with Turbo Boost up to 4.5GHz or 2.3GHz 8-core ', NULL, 'lenovo3.jpg', NULL, NULL, 18, NULL),
('Lenovo IdeaPad Slim 5i 11th Gen Intel Core i5 15.6 1TB HDD+256GB SSD', '21212', '10th Generation Intel Core i5-1035G4', '12.3 inch 2736 x 1824 Pixelsense display | Touchscreen enabled', '512GB or 1TB SSD', '2.6GHz 6-core 9th-generation Intel Core i7 processor with Turbo Boost up to 4.5GHz or 2.3GHz 8-core ', '256GB SSD/128GB SSD', 'lenovo4.jpg', NULL, NULL, 19, NULL),
('Lenovo IdeaPad Slim 5i 11th Gen Intel Core i5 15.6 1TB HDD+256GB SSD', '342342', 'Ninth-generation 6-core Intel Core i7 processor', '12.3 inch 2736 x 1824 Pixelsense display | Touchscreen enabled', 'Pre-Loaded Windows 10 Home with Lifetime Validity', '2.6GHz 6-core 9th-generation Intel Core i7 processor with Turbo Boost up to 4.5GHz or 2.3GHz 8-core ', '256GB SSD/128GB SSD', 'lenovo3.jpg', NULL, NULL, 20, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `label`
--

CREATE TABLE `label` (
  `title` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `label`
--

INSERT INTO `label` (`title`, `id`) VALUES
('Apple', 1),
('Microsoft', 2),
('Dell', 3),
('Lenovo', 4);

-- --------------------------------------------------------

--
-- Table structure for table `lenovo`
--

CREATE TABLE `lenovo` (
  `photo` varchar(100) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `processor` varchar(100) DEFAULT NULL,
  `ram` varchar(100) DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `ssd` varchar(100) DEFAULT NULL,
  `display` varchar(100) DEFAULT NULL,
  `warranty` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `yearofuse` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `order1`
--

CREATE TABLE `order1` (
  `j` varchar(20) DEFAULT NULL,
  `k` varchar(20) DEFAULT NULL,
  `id_name` varchar(20) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `order_conformation` varchar(20) DEFAULT NULL,
  `order_Dispatch` varchar(20) DEFAULT NULL,
  `order_dilever` varchar(20) DEFAULT NULL,
  `order_cancel` varchar(20) DEFAULT NULL,
  `a` varchar(20) DEFAULT NULL,
  `b` varchar(20) DEFAULT NULL,
  `c` varchar(20) DEFAULT NULL,
  `d` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order1`
--

INSERT INTO `order1` (`j`, `k`, `id_name`, `id`, `order_conformation`, `order_Dispatch`, `order_dilever`, `order_cancel`, `a`, `b`, `c`, `d`) VALUES
('8', '1', '10', 1, ' 6 March 2021 ', ' 6 March 2021 ', NULL, ' 6 March 2021 ', '1', '2', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `password1` varchar(100) DEFAULT NULL,
  `confirm_password` varchar(100) DEFAULT NULL,
  `phone_number` varchar(100) DEFAULT NULL,
  `verify` varchar(100) DEFAULT NULL,
  `status1` varchar(20) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `address` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`first_name`, `last_name`, `country`, `Email`, `password1`, `confirm_password`, `phone_number`, `verify`, `status1`, `id`, `address`) VALUES
('Amaan', 'Khan', 'India', 'adminecommerce@gmail.com', 'rootcanacess123', 'rootcanacess123', '8104547361', 'on', '1', 1, NULL),
('Amaan', 'Khan', 'India', 'amaanatiqur12@gmail.com', 'Amaankhanking128', 'Amaankhanking128', '9619588669', 'on', '1', 2, NULL),
('Ansari', 'Amaan', 'India', 'Ansari@gmail.com', 'aaaa', 'aaaa', '8104547362', 'on', '1', 4, NULL),
('Ansari', 'Amaan', 'India', 'Ansari2@gmail.com', 'aaaa', 'aaaa', '8104547261', 'on', '1', 6, NULL),
('Ansari', 'Amaan', 'India', 'Ansar3i@gmail.com', 'aaaa', 'aaaa', '8102547361', 'on', '1', 7, NULL),
('Ansari', 'Amaan', 'India', 'Ans33ri@gmail.com', 'aaaa', 'aaaa', '8333547361', 'on', '1', 8, NULL),
('Ansari', 'Amaan', 'India', '2222@gmail.com', 'aaaa', 'aaaa', '8133337361', 'on', '1', 10, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `search`
--

CREATE TABLE `search` (
  `name` varchar(100) DEFAULT NULL,
  `j` varchar(20) DEFAULT NULL,
  `k` varchar(20) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `search`
--

INSERT INTO `search` (`name`, `j`, `k`, `id`) VALUES
('Mi Notebook 14 Intel Core i5-10210U 10th Gen Thin 14-Inch (1920X 1080 )', '6', '6', 1),
('Apple MacBook Pro 16-inch 9th Gen IntelCore i7', '8', '2', 2),
('Apple MacBook Pro 16-inch 9th Gen IntelCore i7', '8', '3', 3),
('Apple MacBook Pro 16-inch 9th Gen IntelCore i7', '8', '4', 4),
('Apple MacBook Pro 16-inch 9th Gen IntelCore i7', '8', '5', 5),
('Microsoft Surface Pro 7  Intel Core i5 2.3 inch', '8', '6', 6),
('Microsoft Surface Pro 7  Intel Core i5 2.3 inch', '8', '7', 7),
('Microsoft Surface Pro 7  Intel Core i5 2.3 inch', '8', '8', 8),
('Microsoft Surface Pro 7  Intel Core i5 2.3 inch', '8', '9', 9),
('Microsoft Surface Pro 7  Intel Core i5 2.3 inch', '8', '10', 10),
('Lenovo IdeaPad Slim 5i 11th Gen Intel Core i5 15.6 1TB HDD+256GB SSD', '8', '16', 11),
('Lenovo IdeaPad Slim 5i 11th Gen Intel Core i5 15.6 1TB HDD+256GB SSD', '8', '17', 12),
('Lenovo IdeaPad Slim 5i 11th Gen Intel Core i5 15.6 1TB HDD+256GB SSD', '8', '18', 13),
('Lenovo IdeaPad Slim 5i 11th Gen Intel Core i5 15.6 1TB HDD+256GB SSD', '8', '19', 14),
('Dell Inspiron 3505 15.6\" FHD Anti Glare Display Laptop', '8', '11', 16),
('Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '8', '12', 17),
('Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '8', '13', 18),
('Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '8', '14', 19),
('Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '8', '15', 20),
('Lenovo IdeaPad Slim 5i 11th Gen Intel Core i5 15.6 1TB HDD+256GB SSD', '8', '20', 21);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `8133337361_cookies`
--
ALTER TABLE `8133337361_cookies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `8133337361_order`
--
ALTER TABLE `8133337361_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `8333547361_cookies`
--
ALTER TABLE `8333547361_cookies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apple_macbook`
--
ALTER TABLE `apple_macbook`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `asus`
--
ALTER TABLE `asus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dell`
--
ALTER TABLE `dell`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hp`
--
ALTER TABLE `hp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `index_page`
--
ALTER TABLE `index_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `label`
--
ALTER TABLE `label`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lenovo`
--
ALTER TABLE `lenovo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order1`
--
ALTER TABLE `order1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `search`
--
ALTER TABLE `search`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `8133337361_cookies`
--
ALTER TABLE `8133337361_cookies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `8133337361_order`
--
ALTER TABLE `8133337361_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `8333547361_cookies`
--
ALTER TABLE `8333547361_cookies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `apple_macbook`
--
ALTER TABLE `apple_macbook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `asus`
--
ALTER TABLE `asus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dell`
--
ALTER TABLE `dell`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hp`
--
ALTER TABLE `hp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `index_page`
--
ALTER TABLE `index_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `label`
--
ALTER TABLE `label`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `lenovo`
--
ALTER TABLE `lenovo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `order1`
--
ALTER TABLE `order1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `search`
--
ALTER TABLE `search`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
