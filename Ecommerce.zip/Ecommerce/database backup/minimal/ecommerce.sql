-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 01, 2021 at 07:46 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `8133337361_cookies`
--

CREATE TABLE `8133337361_cookies` (
  `j_for_select` varchar(20) DEFAULT NULL,
  `k_for_product` varchar(20) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `8133337361_cookies`
--

INSERT INTO `8133337361_cookies` (`j_for_select`, `k_for_product`, `id`) VALUES
('8', '17', 2),
('8', '9', 3),
('8', '13', 4),
('8', '19', 5);

-- --------------------------------------------------------

--
-- Table structure for table `8133337361_order`
--

CREATE TABLE `8133337361_order` (
  `j_for_select` varchar(20) DEFAULT NULL,
  `k_for_product` varchar(20) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `8333547361_cookies`
--

CREATE TABLE `8333547361_cookies` (
  `j_for_select` varchar(20) DEFAULT NULL,
  `k_for_product` varchar(20) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `8333547361_cookies`
--

INSERT INTO `8333547361_cookies` (`j_for_select`, `k_for_product`, `id`) VALUES
('8', '17', 18),
('8', '7', 19),
('6', '5', 20);

-- --------------------------------------------------------

--
-- Table structure for table `apple_macbook`
--

CREATE TABLE `apple_macbook` (
  `photo` varchar(100) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `processor` varchar(100) DEFAULT NULL,
  `ram` varchar(100) DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `ssd` varchar(100) DEFAULT NULL,
  `display` varchar(100) DEFAULT NULL,
  `warranty` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `yearofuse` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `apple_macbook`
--

INSERT INTO `apple_macbook` (`photo`, `price`, `processor`, `ram`, `os`, `ssd`, `display`, `warranty`, `name`, `yearofuse`, `id`) VALUES
('hp-14.jpg', '66556', '10th Gz Intel Core i5-10210U processor, 1.6 GHz base speed, 4.2 GHz max speed, 4 Cores, 8 threads', '4GB DDR4 RAM, with AMD Radeon', 'Windows 10 Home operating system | Pre-installed software : Office 365 – one month Trial', '128GB or 256GB SSD', '15.6-Inch HD Display, 220 nits, 45% NTSC', '1 Year manufacturer warranty from the date of purchase for both Laptop and Webcam', 'Mi Notebook 14 Intel Core i5-10210U 10th Gen Thin 14-Inch (1920X 1080 )', '', 5);

-- --------------------------------------------------------

--
-- Table structure for table `asus`
--

CREATE TABLE `asus` (
  `photo` varchar(100) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `processor` varchar(100) DEFAULT NULL,
  `ram` varchar(100) DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `ssd` varchar(100) DEFAULT NULL,
  `display` varchar(100) DEFAULT NULL,
  `warranty` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `yearofuse` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `comment1`
--

CREATE TABLE `comment1` (
  `comment1` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comment1`
--

INSERT INTO `comment1` (`comment1`) VALUES
('dsds'),
('dsds'),
('adssad'),
('dsds'),
('sasasd'),
('dsds'),
('dsds'),
('dsds'),
('Amaan khan');

-- --------------------------------------------------------

--
-- Table structure for table `dell`
--

CREATE TABLE `dell` (
  `photo` varchar(100) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `processor` varchar(100) DEFAULT NULL,
  `ram` varchar(100) DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `ssd` varchar(100) DEFAULT NULL,
  `display` varchar(100) DEFAULT NULL,
  `warranty` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `yearofuse` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `hp`
--

CREATE TABLE `hp` (
  `photo` varchar(100) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `processor` varchar(100) DEFAULT NULL,
  `ram` varchar(100) DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `ssd` varchar(100) DEFAULT NULL,
  `display` varchar(100) DEFAULT NULL,
  `warranty` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `yearofuse` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hp`
--

INSERT INTO `hp` (`photo`, `price`, `processor`, `ram`, `os`, `ssd`, `display`, `warranty`, `name`, `yearofuse`, `id`) VALUES
('hp1.jpg', '67655', '1.8GHz dual-core 5th-generation Intel Core i5 with Turbo Boost up to 2.9GHz', '8GB DDR4-2666MHz RAM and  Storage: 256 GB SSD', 'MacOS 10.12 Sierra', '8GB DDR4-2666MHz RAM and  Storage: 256 GB SSD', '15.6-Inch HD Display, 220 nits, 45% NTSC', 'This genuine HP laptop comes with a 1-year domestic warranty from HP', 'Mi Notebook 14 Intel Core i5-10210U 10th Gen Thin 14-Inch (1920X 1080 )', '1 year used, no scratch ,with charger', 1);

-- --------------------------------------------------------

--
-- Table structure for table `image_index`
--

CREATE TABLE `image_index` (
  `photo` varchar(100) DEFAULT NULL,
  `processor` varchar(100) DEFAULT NULL,
  `ram` varchar(100) DEFAULT NULL,
  `ssd` varchar(100) DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `display` varchar(100) DEFAULT NULL,
  `warranty` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `yearofuse` varchar(100) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `content` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `image_index`
--

INSERT INTO `image_index` (`photo`, `processor`, `ram`, `ssd`, `os`, `display`, `warranty`, `name`, `yearofuse`, `price`, `content`, `id`) VALUES
('hp-1.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 1),
('hp-2.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 2),
('dell.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '5999', 'Dell Inspiron 5590', 3),
('hp-4.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 4),
('hp-5.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 5),
('hp-6.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 6),
('hp-7.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 7),
('dell77.png', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '1 year used, no scratch ,with charger', '45654', 'Dell Inspiron 5590', 8),
('hp-9.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 9),
('hp-10.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 10),
('hp-11.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 11),
('hp-12.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 12),
('hp-13.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 13),
('dell.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 14),
('hp-14.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 15),
('hp-15.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 16),
('dell77.png', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '56566', 'Dell Inspiron 5590', 17),
('hp-16.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 18),
('hp-17.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 19),
('hp-18.jpg', '10th Gen Intel Core i5', '8 GB RAM, 512 GB Internal Storage', '512 GB Internal Storage', 'Windows 10 Home Single Language Operating System', '39.62 cm (15.6 inch) Full HD Display', '1 Year manufacturer warranty', 'Dell Inspiron 5590 10th Gen Intel Core i5 39.62 cm (15.6 inch)', '', '59999', 'Dell Inspiron 5590', 20);

-- --------------------------------------------------------

--
-- Table structure for table `label`
--

CREATE TABLE `label` (
  `title` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `label`
--

INSERT INTO `label` (`title`, `id`) VALUES
('Laptop', 1),
('laptop', 2),
('Laptop', 3),
('laptop', 4);

-- --------------------------------------------------------

--
-- Table structure for table `lenovo`
--

CREATE TABLE `lenovo` (
  `photo` varchar(100) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `processor` varchar(100) DEFAULT NULL,
  `ram` varchar(100) DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `ssd` varchar(100) DEFAULT NULL,
  `display` varchar(100) DEFAULT NULL,
  `warranty` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `yearofuse` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `password1` varchar(100) DEFAULT NULL,
  `confirm_password` varchar(100) DEFAULT NULL,
  `phone_number` varchar(100) DEFAULT NULL,
  `verify` varchar(100) DEFAULT NULL,
  `status1` varchar(20) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `address` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`first_name`, `last_name`, `country`, `Email`, `password1`, `confirm_password`, `phone_number`, `verify`, `status1`, `id`, `address`) VALUES
('Amaan', 'Khan', 'India', 'adminecommerce@gmail.com', 'rootcanacess123', 'rootcanacess123', '8104547361', 'on', '1', 1, NULL),
('Amaan', 'Khan', 'India', 'amaanatiqur12@gmail.com', 'Amaankhanking128', 'Amaankhanking128', '9619588669', 'on', '1', 2, NULL),
('Ansari', 'Amaan', 'India', 'Ansari@gmail.com', 'aaaa', 'aaaa', '8104547362', 'on', '1', 4, NULL),
('Ansari', 'Amaan', 'India', 'Ansari2@gmail.com', 'aaaa', 'aaaa', '8104547261', 'on', '1', 6, NULL),
('Ansari', 'Amaan', 'India', 'Ansar3i@gmail.com', 'aaaa', 'aaaa', '8102547361', 'on', '1', 7, NULL),
('Ansari', 'Amaan', 'India', 'Ans33ri@gmail.com', 'aaaa', 'aaaa', '8333547361', 'on', '1', 8, NULL),
('Ansari', 'Amaan', 'India', '2222@gmail.com', 'aaaa', 'aaaa', '8133337361', 'on', '1', 10, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `8133337361_cookies`
--
ALTER TABLE `8133337361_cookies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `8133337361_order`
--
ALTER TABLE `8133337361_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `8333547361_cookies`
--
ALTER TABLE `8333547361_cookies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apple_macbook`
--
ALTER TABLE `apple_macbook`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `asus`
--
ALTER TABLE `asus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dell`
--
ALTER TABLE `dell`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hp`
--
ALTER TABLE `hp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `image_index`
--
ALTER TABLE `image_index`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `label`
--
ALTER TABLE `label`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lenovo`
--
ALTER TABLE `lenovo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `8133337361_cookies`
--
ALTER TABLE `8133337361_cookies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `8133337361_order`
--
ALTER TABLE `8133337361_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `8333547361_cookies`
--
ALTER TABLE `8333547361_cookies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `apple_macbook`
--
ALTER TABLE `apple_macbook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `asus`
--
ALTER TABLE `asus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dell`
--
ALTER TABLE `dell`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hp`
--
ALTER TABLE `hp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `image_index`
--
ALTER TABLE `image_index`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `label`
--
ALTER TABLE `label`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `lenovo`
--
ALTER TABLE `lenovo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
