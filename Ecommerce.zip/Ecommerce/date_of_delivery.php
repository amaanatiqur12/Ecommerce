<?php
	session_start();
	require('connection.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<style>
	/*create table Order1(j varchar(20),k varchar(20),id_name varchar(20),a varchar(20),b varchar(20),c varchar(20),d varchar(20),id int auto_increment primary key);*/
table, td, th {
  border: 1px solid black;
}

table {
  width: 100%;
  border-collapse: collapse;
}
</style>
	<div style="border: 1px solid;margin-left: 5%;margin-top: 10%;padding-left:3%;padding-right: 3%;padding-top: 2%;margin-right: 3%;margin-bottom: 2%;padding-bottom: 3%">
	<h1 style="margin-bottom: 3%">Order Date</h1>
	<?php
		$id=$_GET['id'];
		$str="select * from order1 where id='$id'";
		$result = $conn->query($str) or die($conn->error);
		$data = $result->fetch_array(MYSQLI_ASSOC);
		$order_conformation=$data['order_conformation'];
		$order_Dispatch=$data['order_Dispatch'];
		$order_dilever=$data['order_dilever'];
		$order_cancel=$data['order_cancel'];
	?>
		<table>
		<tr>
			<th style="padding-top: 1%;padding-bottom: 1%">
				Order Conformation
			</th>
			<?php
			if($order_conformation=='')
			{
			echo "<th style='font-size:220%'>
				-
			</th>";	
			}
			else
			{
			echo "<th>
				$order_conformation
			</th>";
			}
			?>
		</tr>
		<tr>
			<th style="padding-top: 1%;padding-bottom: 1%">
				Order Dispatch
			</th>
			<?php
			if($order_Dispatch=='')
			{
			echo "<th style='font-size:220%'>
				-
			</th>";	
			}
			else
			{
			echo "<th>
				$order_Dispatch
			</th>";
		}
			?>
		</tr>
		<tr>
			<th style="padding-top: 1%;padding-bottom: 1%">
				Order Dilever
			</th>
			<?php
			if($order_dilever=='')
			{
			echo "<th style='font-size:220%'>
				-
			</th>";	
			}
			else
			{
			echo "<th>
				$order_dilever
			</th>";
			}
			?>
		</tr>
		<tr>
			<th style="padding-top: 1%;padding-bottom: 1%">
				Order Cancel
			</th>
			<?php
			if($order_cancel=='')
			{
			echo "<th style='font-size:220%'>
				-
			</th>";	
			}
			else{
			echo "<th>
				$order_cancel
			</th>";
		}
			?>
		</tr>
		
	</table>
	</div>
</body>
</html>