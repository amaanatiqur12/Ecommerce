<?php
	session_start();
	require('connection.php'); 
	$j=$_SESSION['j_for_select'];
	$k=$_SESSION['k_for_product'];
	$phone_number=$_SESSION['Identity_database'];
	$str= "insert into `{$phone_number}_cookies` (j_for_select,k_for_product) values ($j,$k)";
	$result = $conn->query($str) or die($conn->error);
	header('location:cart_user.php');
?>