<?php
	session_start();
	require('connection.php');
	ob_start();	
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="layout1.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body >
	<?php
     	include("header_admin.php");
     ?>

     <?php
     if(isset($_GET['id_select']))
     {
     	$id_select=$_GET['id_select'];
     	setcookie('id_select',"$id_select",time()+3600000000);
     }
     ?>
   <label ><h1 style="margin-left: 5%;margin-bottom: 3%;margin-top: 2%">Enter Details</h1></label>
   	<form action="" style="margin-left: 36%;margin-bottom:1%" class="form">

		<div style="padding-top: 3%;float: left;">
		<select class="detail_number" name="detail_number" style="padding-top:1%;padding-bottom: 1%;padding-left:1%;margin-top: 1%;font-size: 22px;padding-right:5%;" name="country_name">
			<option selected="selected" disabled="true" >Number of Details</option>
   			
   			<option value="2">2</option>
   			<option value="3">3</option>
   			<option value="4">4</option>
   			<option value="5">5</option>
   			<option value="6">6 </option>
   			<option value="7">7</option>
   			<option value="8">8</option>
  		 	<option value="9">9</option>
   			<option value="10">	10</option>
		</select>
	 	<ul class="detail_number_check " style="  list-style-type: none;font-size: 12px;color: red;margin-top: 1%"></ul>
		</div>

		<div style="float: left;margin-top: 3%;margin-left: 5%">
			<button style="padding: 20% 35%;float: left">Submit</button>
		</div>
	</form>
	
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.0.min.js"></script>
      <script type="text/javascript">
     
         
         $('.form').on('submit', function() {
            id_select_input=$(".detail_number").val();
            
            console.log(id_select_input)
            i=0
            if(id_select_input==null)
            {
                console.log("Amaan")
               i=1;
               $(".detail_number").addClass("error")
               str=`<li><h1 style="font-size:12px;font-family: arial;"><i class="fa fa-exclamation-circle" style="margin-right:2%"></i>Select Number first,How many details?</h1></li>`;
               $(".detail_number_check").empty();
               $(".detail_number_check").append(str);
            }
            else
            {
               $(".detail_number").removeClass("error")  
               $(".detail_number_check").empty();     
            }
             if(i==0)
             {
                  return true
             }
             else
             {
                  return false
             }
         })
	</script>
	<?php
	if(isset($_GET['detail_number']))
	{
		$i=3;

		$detail_number=$_GET['detail_number'];

		echo "<form action='add_image_index_edit.php?count=$detail_number' method='post'enctype='multipart/form-data'><div style='width:100%;float:left;margin-top:5%'><label style='float:left;margin-left:6%'>Photo:</label><bR><input type='file' style='margin-left:6%;margin-top:2%' name='file'></div>";
		echo "<div style='width:100%;float:left'><label style='float:left;margin-top:3%;margin-left:6%'>Name of Product:</label><input type='txt' class='detail$i' style='float:left;margin-top:7%;padding: 5px 10px;width:30%' name='name'><br><div>";
		echo "<div style='width:100%;float:left'><label style='float:left;margin-top:3%;margin-left:6%'>Price:</label><input type='number' class='detail$i' style='float:left;margin-top:7%;padding: 5px 10px;width:30%' name='price'><br><div>";
			while ($i<=$detail_number) {

			
			echo "<div style='width:100%;float:left'><label style='float:left;margin-top:3%;margin-left:6%'>Detail$i:</label><input type='txt' class='detail$i' style='float:left;margin-top:7%;padding: 5px 10px;width:30%' name='detail$i'><br><div>";
			$i++;	
		}
		echo "<div style='width:100%;float:left'><button style='margin-left: 5%;margin-top: 3%;margin-bottom: 9%;padding: 5px 10px;background-color: green;border:2px solid 	#F0F8FF;border-radius: 7px'>Submit</button></div></form>";
	}
	
	?>
	
	
</body>
</html>