<?php
	
	$username = "amaanatiqur12@gmail.com";
	$hash = "c5477e8ddc5ea5c2f9e535b2b701176843116e7172c0939532475ae84ee2950a";


	
	$test = "0";

	
	$sender = "TXTLCL"; 
	$numbers =  "91".$_REQUEST['phone_number']; 
	$message = "hello";
	
	$message = urlencode($message);
	$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
	
	$api="http://api.textlocal.in/send/?".$data;
	echo $api;
	$result=file($api);
	var_dump($result);



?>