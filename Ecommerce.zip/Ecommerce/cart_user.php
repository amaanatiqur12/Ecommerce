<?php
	session_start();
	require('connection.php');
  ob_start(); 
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="layout1.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>
		<?php
	if(isset($_COOKIE['id_admin']))
	{
     	include("header_admin.php");
     }
     elseif (isset($_COOKIE['id'])) {   		
     	include("header.php");
     }
       else{
     	include("header.php");
     }
     ?>
	<style>
		table, th, td {
 		border: 1px solid black;
  		border-collapse: collapse;
		}
	</style>



	     <?php 
            if(!isset($_COOKIE['id']))
            {
                header('location:cart.php');
            }
       ?>
	
  	
  		<div style="width:70%;margin-left: 2%;margin-top: 3%;padding-top: 3%;padding-bottom: 10%;border:1px solid;float: left;margin-bottom: 1%">
    	
    	<div>
    		<p style="float: left;font-size: 30px;margin-left: 2%">Shopping cart</p>
    		<p style="float: right;margin-right: 2%">Price</p>
    	</div>
    	<hr style="margin-left: 2%;margin-right: 2%;margin-top: 4%">	

    <?php
        $i=1;
        
        $l=0;
        $id_user=$_COOKIE['id'];
        $str="select * from registration where id='$id_user'";
        $result = $conn->query($str) or die($conn->error);
        $data = $result->fetch_array(MYSQLI_ASSOC);
         $phone_number=$data['phone_number'];
         
		  	$str="select * from `{$phone_number}_cookies`";
        $result = $conn->query($str) or die($conn->error);
       echo "<form action='cart_user_add.php' class='form'> ";
        if($result->num_rows > 0){
        
        while($data = $result->fetch_array(MYSQLI_ASSOC)) 
        { 
          // echo $i;
        $j=$data['j_for_select'];
        $k=$data['k_for_product'];
        $id=$data['id'] ; 
			
			if($j==3)
			{
				$str = "select * from hp where id='$k'";
			}
			elseif ($j==4) {
				$str = "select * from dell where id='$k'";
			}
			elseif($j==5){
				$str = "select * from Asus where id='$k'";
			}
			elseif($j==6){
				$str = "select * from apple_macbook where id='$k'";
			}
			elseif($j==7){
				$str = "select * from Lenovo where id='$k'";
			}
			elseif($j==8){
				$str="select * from index_page where id='$k'";
			}

			

			$result1 = $conn->query($str) or die($conn->error);	
			// var_dump($result);
			
				$data2 = $result1->fetch_array(MYSQLI_ASSOC) ;
				// print_r($data) ;

					$photo=$data2['image'];
					$price=$data2['price'];
					
					$Name=$data2['name'];
					$l++;
			if($i==1)
			{	
			$l=$i;	
			
    	echo "<div style='padding-top:10%'>
    		<div style='float: left;width: 30%'>
    			<input type='checkbox' style='float: left;margin-top: 27%;margin-left: 6%;margin-right: 2%' value='$price?j=$j&k=$k' class='checkbox' name='value$id'>
    			<img src='img/$photo' style='float: left;width:60%'>
    		</div>
    		<div style='float: left;width: 70%'>
    			<div>
    				<p style='float: left;'>$Name</p>
    				<p style='float: right;padding-right: 3%'>&#8377; $price</p>
    			</div>
    			<br>
    			<br>
    			<div  style='margin-top: 15%'>
    				<input type='' name='' style='width: 4%;float: left;' value='1'>
    				<a href='delete_cart_user.php?l=$id' style='float: left;text-decoration: none;margin-left:4%'>Delete</a>
    				

    			</div>
    		</div>
    	</div>";
    }
    else
    {
    	$l=$i;	
			

    	echo "<div style='padding-top:30%'>
    		<div style='float: left;width: 30%'>
    			<input type='checkbox' style='float: left;margin-top: 27%;margin-left: 6%;margin-right: 2%' value='$price?j=$j&k=$k' class='checkbox' name='value$id'>
    			<img src='img/$photo' style='float: left;width:60%'>
    		</div>
    		<div style='float: left;width: 70%'>
    			<div>
    				<p style='float: left;'>$Name</p>
    				<p style='float: right;padding-right: 3%'>&#8377; $price</p>
    			</div>
    			<br>
    			<br>
    			<div  style='margin-top: 15%'>
    				<input type='' name='' style='width: 4%;float: left;' value='1'>
    				<a href='delete_cart_user.php?l=$id' style='float: left;text-decoration: none;margin-left:4%'>Delete</a>
    				

    			</div>
    		</div>
    	</div>";
    }
    $i++;
  }
    }
    
    	?>
</form>
    	</div>
    	
    	
  	
  
	
	<div style="width: 24%;height: 190px;border:1px solid;float: left;margin-left: 2%;margin-top: 5%">
		<p style="font-size: 15px;margin-left: 2%;margin-top: 8%">Select this option at checkout.<a href="#" style="text-decoration: none"> Details </a></p>
		<ul class="ul_tag_for_price">
			
		</ul>
		
		
	</div>

	<div style="float: left;width: 100%" >
		<hr style="margin-top: 39%;">
		<p style=";margin-left:15%;margin-top: 2%;margin-bottom: 2%">Need some help?Contact Info:+60 16 656 1067</p>
		<div style="width: 100%;height: 110px;background-color: #f5f5f7;">
			<p style="font-size: 12px;color: #86868b;margin-left: 15%;padding-top: 1.4%">Zaranet network 14G, jalan pandan indah 1/23c,Pandan indah, 55100, Kuala Lumpur, Malaysia. <a href="#" style="color: #515154;text-decoration: none"> Security Policy</a>.</p>
			<hr style="margin-top: 1.5%;width: 70%;margin-left: 15%">
		</div>
	</div>
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.0.min.js"></script>

			<script type="text/javascript">

				$(document).ready(function(){
				v=0;
				c=0;
         $( ".checkbox" ).prop( "checked", false );
				$('.checkbox').click(function() {
  				if(this.checked)
  				{
    					  t=$(this).val();
    					  v=parseInt(v) + parseInt(t);
    					  c=parseInt(c)+1;
    					   str=`<li style="margin-left: 2%;margin-top: 6%;font-size: 20px;list-style-type: none;">Subtotal (<span class='items'></span> items):  &#8377;<span class='price'></span></li>
    					   <button style="padding-left: 31%;padding-right: 31%;padding-top: 1.4%;padding-bottom: 1.4%;margin-left: 3%;margin-top:13%;background: #f0c14b;border:1px solid" onClick='submitDetailsForm()'>Proceed to buy</button>`;
               				$(".ul_tag_for_price").empty();
              		 		$(".ul_tag_for_price").append(str);
              		 		$('.items').text(c);
              		 		$('.price').text(v);
    						console.log(v)
  				}
  				else
  				{
  					 t=$(this).val();
  					 v=parseInt(v) - parseInt(t)
  					  c=parseInt(c)-1;
  					   str=`<li style="margin-left: 2%;margin-top: 6%;font-size: 20px;list-style-type: none;">Subtotal (<span class='items'></span> items):  &#8377;<span class='price'></span></li>
    					   <button style="padding-left: 31%;padding-right: 31%;padding-top: 1.4%;padding-bottom: 1.4%;margin-left: 3%;margin-top:13%;background: #f0c14b;border:1px solid" onClick='submitDetailsForm()'>Proceed to buy</button>`;
               				$(".ul_tag_for_price").empty();
              		 		$(".ul_tag_for_price").append(str);
              		 		$('.items').text(c);
              		 		$('.price').text(v);
              		 		if(c==0)
              		 		{
              		 			$(".ul_tag_for_price").empty();
              		 		}
    					console.log(v)
  				}
				});
			})
          function submitDetailsForm() {
       $(".form").submit();
    }
			</script>

</body>
</html>