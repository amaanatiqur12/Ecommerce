<?php
	session_start();
	$_SESSION['href'] = $_GET['href'];
	require('connection.php');
?>
<?php
	session_regenerate_id(true);
	unset($_SESSION['j_for_select']);
	session_regenerate_id(true);
	unset($_SESSION['k_for_product']);
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="layout1.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body >
	<?php
	if(isset($_COOKIE['id_admin']))
	{
     	include("header_admin.php");
     }
     elseif (isset($_COOKIE['id'])) {   		
     	include("header.php");
     }
       else{
     	include("header.php");
     }
     ?>
		
			<?php  
			$i=0;
			$j = $_GET['href'];
			if($j==1)
			{
				$str = "select * from bestsellers";	
			}
			elseif($j==2){
				$str = "select * from newreleases";
			}
			elseif($j==3)
			{
				$str = "select * from hp";
			}
			elseif ($j==4) {
				$str = "select * from dell";
			}
			elseif($j==5){
				$str = "select * from microsoft";
			}
			elseif($j==6){
				$str = "select * from apple";
			}
			elseif($j==7){
				$str = "select * from lenovo";
			}elseif ($j==9) {
				$str = "select * from components ";
			}
			elseif($j==10){
				$str = "select * from bags ";
			}
			elseif($j==11){
				$str = "select * from networkcomponents ";
			}

			

			$result = $conn->query($str) or die($conn->error);	
			// print_r($result);
			if($result->num_rows > 0){
				while($data = $result->fetch_array(MYSQLI_ASSOC)) 
				{

					
					$price=$data['price'];
					$photo=$data['image'];
					$Name=$data['name'];
					$id=$data['id'];
					$k=$id;
					$r=3;
					$u=0;
					while($data['detail'.$r]!=null)
					{
						$u++;
						$r++;
					}	
					$p=0;
					 if(isset($_COOKIE["id_admin"]))
			 		{



			 		echo "<div style='margin-left: 8%;margin-top: 6%;width: 100%;float:left'>
						 <div style='float: left;width:25%'>
							<img src='img/$photo'>
						</div>
						<div style='width:100%'>
						<div style='float:left'>
						<a href='product_view_admin.php?id_index=$j&k=$k' style='text-decoration: none;float:left;margin-left:10%'>$Name</a></div>";
						echo "<div style='float: left;margin-left:15%'>
							<p style='font-size: 26px;margin-left: 36%'><span>&#8377;</span>$price</p>
							
						</div>
						<form action='delete_seach_product.php?id=$id&j=$j' method='post'>
							<button style='margin-left:5%;background-color:white;border:0px' class='btn_hover'>
							<i class='fa fa-times' style='margin-left:5%'></i>
							</button>
						</form>
						</div><br>";	
						echo "<ul style='margin-left:30%;margin-top:3%;'>";
						$h=0;
						$r=3;
						while($h<=$u-1)
						{
							$detail=$data['detail'.$r];
							echo "<li style='margin-top:1%'>$detail</li>";
							$h++;
							$r++;
						}
						echo	"</ul></div></div>";
					
			 		}



			 		
			 		else
			 		{
					//echo $data;
					
					echo "<div style='margin-left: 8%;margin-top: 6%;width: 100%;float:left'>
						 <div style='float: left;width:25%'>
							<img src='img/$photo'>
						</div>
						<div style='width:100%'>
						<div style='float:left'>
						<a href='product_view.php?id_index=$j&k=$k' style='text-decoration: none;float:left;margin-left:10%'>$Name</a>
						</div>
						<div style='float: left;margin-left: 15%'>
							<p style='font-size: 26px;'><span>&#8377;</span>$price</p>
						</div><br>";
						echo "<ul style='margin-left:30%;margin-top:3%;'>";
						$h=0;
						$r=3;
						while($h<=$u-1)
						{
							$detail=$data['detail'.$r];
							echo "<li style='margin-top:1%'>$detail</li>";
							$h++;
							$r++;
						}

						echo	"</ul></div></div>";
						
					
				}
				}
				}
								
			?>
			
				<style type="text/css">
					.btn_hover:hover{
						cursor: pointer;
					}
				</style>
			 <?php

			 if(isset($_COOKIE["id_admin"]))
			 {
			 	echo	"<form action='add_search_product.php'><div style='margin-top: 30%;margin-left: 45%;padding-top: 6%;margin-bottom: 10%'>
						<button style='padding: 5px 15px' >add</button>
						</div></form>";
			}
			

			 ?>
			
			<!-- formaction="services.php?product_service='.$servicename.'"  -->
</body>
</html>