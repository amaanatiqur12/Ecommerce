<?php
session_start();
require 'connection.php';
$l=1;
while(isset($_COOKIE["j_for_select".$l]))
	{
		$j=$_COOKIE["j_for_select".$l];
		$k=$_COOKIE["k_for_product".$l];
		$phone_number=$_SESSION['Identity_database'];
		$str= "insert into `{$phone_number}_cookies` (j_for_select,k_for_product) values ($j,$k)";
		$result = $conn->query($str) or die($conn->error);
		setcookie("j_for_select".$l,$j,time()-3600);
		setcookie("k_for_product".$l,$k,time()-3600);
		
		
		$l=$l+1;
	}
	$l--;
	session_regenerate_id(true);
	unset($_SESSION['value']);
	$_SESSION['value_user']=$l;
	
	header("location:index.php");
?>