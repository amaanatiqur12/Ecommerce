<?php
	session_start();
	require('connection.php');
?>
<?php
	session_regenerate_id(true);
	unset($_SESSION['j_for_select']);
	session_regenerate_id(true);
	unset($_SESSION['k_for_product']);
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>
<style>
	/*create table Order1(j varchar(20),k varchar(20),id_name varchar(20),a varchar(20),b varchar(20),c varchar(20),d varchar(20),id int auto_increment primary key);*/
table, td, th {
  border: 1px solid black;
}

table {
  width: 100%;
  border-collapse: collapse;
}
</style>

<?php
	include("header_admin.php");
?>

<div style="border: 1px solid;margin-left: 5%;margin-top: 10%;padding-left:3%;padding-right: 3%;padding-top: 2%;margin-right: 3%;margin-bottom: 2%;padding-bottom: 3%">
	<h1 style="margin-bottom: 3%">Order</h1>
	<table>
		<tr>
			<th style="padding-top: 2%;padding-bottom: 2%;">
				ID
			</th>
			<th>
				Username<br> Detail
			</th>
			<th>
				Product <br>Detail
			</th>
			<th>
				Order<br> Conformation
			</th>
			<th>
				Order<br> Dispatch
			</th>
			<th>
				Order<br> dilever
			</th>
			<th>
				Order<br> Cancel
			</th>
			<th>
				Order <br>Date
			</th>
		</tr>
		<?php 
			$str = "select * from order1";

			$result = $conn->query($str) or die($conn->error);	
			
			$i=0;
			if($result->num_rows > 0){
				while($data = $result->fetch_array(MYSQLI_ASSOC)) 
				{
					$a=$data['a'];
					$b=$data['b'];
					$c=$data['c'];
					$d=$data['d'];
					$j=$data['j'];
					$k=$data['k'];
					$id=$data['id'];
					$id_user=$data['id_name'];
					$str1="select * from registration where id=$id_user";
					$result1 = $conn->query($str1) or die($conn->error);
					$data1 = $result1->fetch_array(MYSQLI_ASSOC);
					$first=$data1['first_name'];
					$last=$data1['last_name'];
					$arr = array($first,$last);
					$Name= join(" ",$arr);
				if($d!=1)
				{	
					if($a!=1||$b!=2||$c!=2)
				{	
			echo "<tr>";
			echo "<th style='padding-top: 2%;padding-bottom: 2%'>
				$id
			</th>";
			echo "<th style='padding-top: 2%;padding-bottom: 2%'>
				<a href='user_information.php?id_user=$id_user' style='text-decoration: none' value=>$Name</a>
			</th>";
			echo "<th>
				<a href='product_view_admin.php?id_index=$j&k=$k' style='text-decoration: none;'>click</a>
			</th>";

			if($a==0)
			{
			echo "<th>
			<a href='order_tick.php?a=0&id=$id'>
				<button style='background-color: #FF0000;padding: 2% 5%;border:1px solid   #8B0000;border-radius: 9%;' >Confirm</button>
			</a>
			</th>";
			}
			else
			{
				echo "<th><i class='fa fa-check' style='color:green'></i><th>";
			}
			if($a==0)
			{
			echo "<th>
			
				<button style='background-color: #F08080;padding: 2% 5%;border:1px solid   #8B0000;border-radius: 9%;color: black' disabled>Dispatch</button>
			
			</th>";
			}else if($b==1)
			{
              echo "
              <a href='order_tick.php?b=1&id=$id'>
				<button style='background-color: #FF0000;padding: 2% 5%;border:1px solid   #8B0000;border-radius: 9%;'>Dispatch</button>		
			</a>					
			";	
			}else if($b==2)
			{
				echo "<i class='fa fa-check' style='color:green'></i>";
			}
			if($a==0||$b==1)
			{
			echo "<th>
				<button style='background-color: #F08080;padding: 2% 5%;border:1px solid   #8B0000;border-radius: 9%;color: black' disabled>Deliver</button>
			</th>";
			}
			else if($c==1){
			echo "<th>
				<a href='order_tick.php?c=1&id=$id'>
					<button style='background-color: #FF0000;padding: 2% 5%;border:1px solid   #8B0000;border-radius: 9%;'>Deliver</button>
				</a>
				
			</th>";
			}
			else if($c==2)
			{
				echo "<th><i class='fa fa-check' style='color:green'></i><th>";
			}
			
			if($a==0||$b==1||$c==1)
			{
			echo"<th>
				<a href='order_tick.php?d=1&id=$id'>
					<button style='background-color: #FF0000;padding: 2% 5%;border:1px solid   #8B0000;border-radius: 9%;'>Cancel</button>
				</a>
				</th>";
			}
			echo "<th><a href='date_of_delivery.php?id=$id' style='text-decoration:none'>click</a></th>";
			echo "</tr>";
			}
		}
	}
}
		?>	
	</table>
</div>

<div style="border: 1px solid;margin-left: 5%;margin-top: 10%;padding-left:3%;padding-right: 3%;padding-top: 2%;margin-right: 3%;margin-bottom: 2%;padding-bottom: 3%">
	<h1 style="margin-bottom: 3%">Delivered</h1>
	<table>
		<tr>
			<th style="padding-top: 2%;padding-bottom: 2%">
				ID
			</th>
			<th>
				Username<br> Detail
			</th>
			<th>
				Product <br>Detail
			</th>
			<th>
				Order<br> Conformation
			</th>
			<th>
				Order<br> Dispatch
			</th>
			<th>
				Order<br> dilever
			</th>
			<th>
				Order<br> Date
			</th>
			
		</tr>
		<?php 
			$str = "select * from order1";

			$result = $conn->query($str) or die($conn->error);	
			
			$i=0;
			if($result->num_rows > 0){
				while($data = $result->fetch_array(MYSQLI_ASSOC)) 
				{
					$a=$data['a'];
					$b=$data['b'];
					$c=$data['c'];
					$d=$data['d'];
					$j=$data['j'];
					$k=$data['k'];
					$id=$data['id'];
					$id_user=$data['id_name'];
					$str1="select * from registration where id=$id_user";
					$result1 = $conn->query($str1) or die($conn->error);
					$data1 = $result1->fetch_array(MYSQLI_ASSOC);
					$first=$data1['first_name'];
					$last=$data1['last_name'];
					$arr = array($first,$last);
					$Name= join(" ",$arr);
					if($d!=1)
					{
					if($a==1&&$b==2&&$c==2)
					{	
						echo "<tr>";
						echo "<th style='padding-top: 2%;padding-bottom: 2%'>
							$id
							</th>";
						echo "<th style='padding-top: 2%;padding-bottom: 2%'>
							<a href='user_information.php?id_user=$id_user' style='text-decoration: none'>$Name</a>
							</th>";
						echo "<th>
							<a href='product_view_admin.php?id_index=$j&k=$k' style='text-decoration: none;'>click</a>
							</th>";

			
						echo "<th><i class='fa fa-check' style='color:green'></i><th>";
			
			
						echo "<i class='fa fa-check' style='color:green'></i>";
			
			
						echo "<th><i class='fa fa-check' style='color:green'></i><th>";
			
			
					if($a==0||$b==1||$c==1)
						{

					echo"<th>
						<a href='order_tick.php?c=1&id=$id'>
							<button style='background-color: #FF0000;padding: 2% 5%;border:1px solid   #8B0000;border-radius: 9%;'>Cancel</button>
						</a>
						</th>";
					}
					else if($d==2)
						{
							echo "<th><i class='fa fa-check' style='color:green'></i><th>";
							}
						echo "<a href='date_of_delivery.php?id=$id' style='text-decoration:none'>click</a>";
						echo "</tr>";
						}
		}
	}
}
		?>	
	</table>
</div>

<div style="border: 1px solid;margin-left: 5%;margin-top: 10%;padding-left:3%;padding-right: 3%;padding-top: 2%;margin-right: 3%;margin-bottom: 2%;padding-bottom: 3%">
	<h1 style="margin-bottom: 3%">Cancel</h1>
	<table>
		<tr>
			<th style="padding-top: 2%;padding-bottom: 2%">
				ID
			</th>
			<th>
				Username<br> Detail
			</th>
			<th>
				Product <br>Detail
			</th>
			<th>
				Order<br> Conformation
			</th>
			<th>
				Order<br> Dispatch
			</th>
			<th>
				Order<br> dilever
			</th>
			<th>
				Order<br> Date
			</th>
			
		</tr>
		<?php 
			$str = "select * from order1";

			$result = $conn->query($str) or die($conn->error);	
			
			$i=0;
			if($result->num_rows > 0){
				while($data = $result->fetch_array(MYSQLI_ASSOC)) 
				{
					$a=$data['a'];
					$b=$data['b'];
					$c=$data['c'];
					$d=$data['d'];
					$j=$data['j'];
					$k=$data['k'];
					$id=$data['id'];
					$order_conformation=$data['order_conformation'];
					$order_Dispatch=$data['order_Dispatch'];
					$order_dilever=$data['order_dilever'];
					$order_cancel=$data['order_cancel'];
					$id_user=$data['id_name'];
					$str1="select * from registration where id=$id_user";
					$result1 = $conn->query($str1) or die($conn->error);
					$data1 = $result1->fetch_array(MYSQLI_ASSOC);
					$first=$data1['first_name'];
					$last=$data1['last_name'];
					$arr = array($first,$last);
					$Name= join(" ",$arr);
				if($d==1)
				{	
			echo "<tr>";
			echo "<th style='padding-top: 2%;padding-bottom: 2%'>
				$id</th>";
			echo "<th style='padding-top: 2%;padding-bottom: 2%'>
				<a href='user_information.php?id_user=$id_user' style='text-decoration: none'>$Name</a>
			</th>";
			echo "<th>
				<a href='product_view_admin.php?id_index=$j&k=$k' style='text-decoration: none;'>click</a>
			</th>";
			if($order_conformation=='')
			{
				echo "<th><i class='fa fa-times' style='color:red'></i></th>";
			}
			else
			{
				echo "<th><i class='fa fa-check' style='color:green'></i></th>";
			}
			if ($order_Dispatch=='') {
				echo "<th><i class='fa fa-times' style='color:red'></i></th>";
			}
			else
			{
				echo "<th><i class='fa fa-check' style='color:green'></i></th>";	
			}
		
			echo "<th><i class='fa fa-times' style='color:red'></i></th>";
			echo "<th><a href='date_of_delivery.php?id=$id' style='text-decoration:none'>click</a></th>";
			echo "</tr>";
				}
			}
	}
		?>	
	</table>
</div>

</body>
</html>