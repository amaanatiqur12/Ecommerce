<?php
   require('connection.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="layout1.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>
		
		<div style="width: 100%;height:90px;background-color: #C5C6C6;" >
			<button style="float: left;width: 10%;border: 0px solid;height: 15px;margin-left: 45%;margin-top: 1.5%;"class="btn_home" onClick="window.location='index.php';">
				<img src="img/symbol_b.jpeg" style="width: 100%">
			</button>
		</div>
		
		<div style="width:27%;height: 420px;margin-left:36%;border: 1px #ddd solid;margin-top:4%">
				<p style="font-size: 29px;padding-top:15px;padding-left: 20px ">Authentication<br> required</p>
				<div style="margin-top: 3%">
				<p style="font-size: 13px;margin-left: 6%">For your security, we need to authenticate your <br>request. We've sent an OTP to the mobile number <br>+918104547361. Please enter it below to <br>complete verification.</p>
				<h1 style="font-size: 12px;padding-left: 19px;margin-bottom:1%;margin-top: 10% ">Enter OTP</h1>
				<input type="txt" style="width: 80%;height: 20px;margin-left: 5%;padding: 5px 8px" class="login_add_pass">
				<ul class="login_add_pass_li" style="  list-style-type: none;font-size: 12px;margin-left: 5%;color: red;margin-top: 2%"></ul>
				</div>
				<button style="width: 87%;height: 30px;background-color: #C5C6C6;border:1px solid #f7dfa5;margin-left: 4.4%;margin-top: 1%" class="login_continue">Continue</button>				
				<p style="margin-top: 6%;font-size: 13px;margin-left: 5%;font-size: 12px!important;line-height: 1.5!important;">By continuing, you agree to lemontree <span><a href="#" style="text-decoration: none">Conditions of <br>Use </a></span>and <span ><a href="#" style="text-decoration: none">Privacy Notice.</a></span>
				</p>
				<p style="margin-top: 5%;font-size: 13px;margin-left: 5%"><a href="#" style="text-decoration: none">Need help?</a></p>
		</div>
		
		<style type="text/css">
				.error{
					border:1px solid red !important;
				}
		</style>
			<script type="text/javascript">
    			document.getElementById("myButton").onclick = function () {
       		 	location.href = "registration.html";
    			};
			</script>
			<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.0.min.js"></script>
			<script type="text/javascript">
				$(function(){
					$(".login_continue").click(function(){
						login_add_pass=$(".login_add_pass").val();
						if(login_add_pass=="")
						{
							$(".login_add_pass").addClass("error")
				        	str=`<li><i class="fa fa-exclamation" style="margin-right:3%;margin-top:4%"></i>Invalid OTP. Please check your code and try again.</li>`;
				        	$(".login_add_pass_li").empty();
				            $(".login_add_pass_li").append(str);
						}	
						else
						{
							Email_address_input=$(".login_add_pass").val();
							Email_address_varaible_login=/^[a-zA-Z0-9]([a-zA-Z0-9\.]+)?[a-zA-Z0-9]@gmail.com$/
							Email_address_check_login=Email_address_varaible_login.test(Email_address_input);
							if(Email_address_check_login)
							{
								window.location="password.html";
								
    								console.log("amaan") 
							}
							else
							{
								str=`<div  style="border:1px solid red;margin-left:35%;width: 27%;height:87px;box-shadow: 0 0 0 4px #fcf4f4 inset;margin-bottom: 2%;border-radius: 3px;">
			<div>
				<div style="float: left;margin-left: 5%;margin-top: 3%">
					<i class="fa fa-exclamation-triangle" style="font-size:  25px !important;color: #c40000 !important;float: left !important;"></i>
				</div>
				<div style="float: left;margin-top: 3%;margin-left: 3%">
					<p style="color: #c40000;font-weight: 400; font-size: 17px;line-height: 1.255;float: left !important;">There was a problem</p>
				</div>			

			</div>
			<br>
			<br>
			<p style="font-size: 13px;line-height: 19px;/*margin-top: 2%;*/margin-left:15%">We cannot find an account with that email <br>address</p>	
		</div>`;
				        		$(".top_error").empty();
				           		$(".top_error").append(str);
							}
						}

				})
					$(".login_add_pass").keyup(function(){
					  	$(".login_add_pass").removeClass("error")	
				     	$(".login_add_pass_li").empty();		
				});
				})
			</script>

</body>
</html>