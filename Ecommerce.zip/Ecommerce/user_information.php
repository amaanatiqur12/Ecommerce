<?php
	session_start();
	require('connection.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<style>
	/*create table Order1(j varchar(20),k varchar(20),id_name varchar(20),a varchar(20),b varchar(20),c varchar(20),d varchar(20),id int auto_increment primary key);*/
table, td, th {
  border: 1px solid black;
}

table {
  width: 100%;
  border-collapse: collapse;
}
</style>
<div style="border: 1px solid;margin-left: 5%;margin-top: 10%;padding-left:3%;padding-right: 3%;padding-top: 2%;margin-right: 3%;margin-bottom: 2%;padding-bottom: 3%">
	<h1 style="margin-bottom: 3%">User Information</h1>
	<?php
			$id=$_GET['id_user'];
			$str1="select * from registration where id=$id";
			$result1 = $conn->query($str1) or die($conn->error);
			$data1 = $result1->fetch_array(MYSQLI_ASSOC);
			$first=$data1['first_name'];
			$last=$data1['last_name'];
			$arr = array($first,$last);
			$Name= join(" ",$arr);
			$Email=$data1['Email'];
			$phone_number=$data1['phone_number'];
			$Country=$data1['country'];
			$address=$data1['address'];

	?>
	<table>
		<tr>
			<th style="padding-top: 1%;padding-bottom: 1%">
				Name
			</th>
			<?php
			echo "<th>
				$Name
			</th>";
			?>
		</tr>
		<tr>
			<th style="padding-top: 1%;padding-bottom: 1%">
				Email
			</th>
			<?php
			echo "<th>
				$Email
			</th>";
			?>
		</tr>
		<tr>
			<th style="padding-top: 1%;padding-bottom: 1%">
				Phone number
			</th>
			<?php
			echo "<th>
				$phone_number
			</th>";
			?>
		</tr>
		<tr>
			<th style="padding-top: 1%;padding-bottom: 1%">
				Country
			</th>
			<?php
			echo "<th>
				$Country
			</th>";
			?>
		</tr>
		<tr>
			<th style="padding-top: 1%;padding-bottom: 1%">
				Address
			</th>
			<?php
			echo "<th>
				$address
			</th>";
			?>
		</tr>	
	</table>
</div>		
</body>
</html>