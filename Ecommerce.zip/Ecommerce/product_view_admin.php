<?php
 	session_start();
	require('connection.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="layout1.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>
	<?php
     	include("header_admin.php");
    ?>
   
		<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.0.min.js"></script>

			<script type="text/javascript">
			
			$(document).ready(function(){
	  		$(window).scroll(function(){
	  		console.log( $(window).scrollTop() );
	  			if($(window).scrollTop() >200 ){
	  				$(".marks1").css({
	  				"position":"static",
	  				"margin-top":"280px",
	  				"width":"160%"
	  			});
	  		}
	  		else {
				$(".marks1").css({
	  				"position":"fixed",
	  				 "margin-top":"0px",
	  				 "width": "40%"				
	  				});
	  			}
	  		});
		});
			</script>
			<?php  
			$i=0;

			if(isset($_SESSION['j_for_select']))
			{
				$j=$_SESSION['j_for_select'];
				$k=$_SESSION['k_for_product'];
				

			}
			else
			{
				if(isset($_GET['id_index']))
				{
					
					$j=$_GET['id_index'];
					$k=$_GET['k'];
					$_SESSION['j_for_select']=$j;
					$_SESSION['k_for_product']=$k;
				}
				else
				{
				
					$j = $_SESSION['href'];	
					$k = $_GET['id'];
					$_SESSION['j_for_select']=$j;
					$_SESSION['k_for_product']=$k;
				}
			}
			
			// echo $j;
			// echo $k;
			if($j==1)
			{
				$str = "select * from bestsellers where id='$k'";	
			}
			elseif($j==2){
				$str = "select * from newreleases where id='$k'";
			}
			elseif($j==3)
			{
				$str= "select * from hp where id='$k'";
			}
			elseif ($j==4) {
				$str = "select * from dell where id='$k'";
			}
			elseif($j==5){
				$str = "select * from microsoft where id='$k'";
			}
			elseif($j==6){
				$str = "select * from apple where id='$k'";
			}
			elseif($j==7){
				$str = "select * from lenovo where id='$k'";
			}
			elseif($j==8){
				$str = "select * from index_page where id='$k'";	
			}
			elseif ($j==9) {
				$str = "select * from components where id='$k'";
			}
			elseif($j==10){
				$str = "select * from bags where id='$k'";
			}
			elseif($j==11){
				$str = "select * from networkcomponents where id='$k'";
			}
			

			$result = $conn->query($str) or die($conn->error);	
			// var_dump($result);
			
				$data = $result->fetch_array(MYSQLI_ASSOC) ;
				// print_r($data) ;

					$photo=$data['image'];
					$price=$data['price'];
					$Name=$data['name'];
					$id=$data['id'];
				$r=3;
				$u=0;
				while($data['detail'.$r]!=null)
				{
					$u++;
					$r++;
				}	
		if(isset($_COOKIE['id']))
		{			
		echo "<div style='margin-top:7%'>
			<div style='float: left;height: 150px;width: 25%;margin-left: 3%;margin-top: 3%;margin-bottom: 40%;'>
				<div class='marks1' style='position: fixed;width:40%'>
					<img src='img/$photo' style='width: 25%;z-index:-1;width:60%' >
					
				 </div>
			</div>			
			<div style='margin-top:3%;margin-left:6%;float:left'>
				<p style='font-size:20px'>$Name</p>
				<div>
					<p style='margin-top: 5%;font-size: 22px;float:left'>Price:₹ $price</p>
				
				</div>
				<p style='margin-top:20%;font-size:19px;'>Product Detail</p>
				<ul style='margin-left:3%;margin-top:3%'>";
				$h=0;
				$r=3;
				while($h<=$u-1)
				{
					$detail=$data['detail'.$r];
					echo "<li style='margin-top:1%'>$detail</li>";
					$h++;
					$r++;
				}
				

			echo	"</ul></div></div>";
		}else{
			echo "<div style='margin-top:7%'>
			<div style='float: left;height: 150px;width: 25%;margin-left: 3%;margin-top: 3%;margin-bottom: 40%;'>
				<div class='marks1' style='position: fixed;width:40%'>
					<img src='img/$photo' style='width: 25%;z-index:-1;width:60%' >
					
				 </div>
			</div>			
			<div style='margin-top:3%;margin-left:6%;float:left'>
				<p style='font-size:20px'>$Name</p>
				<div>
					<p style='margin-top: 5%;font-size: 22px;float:left'>Price:₹ $price</p>
					
				</div>
				<p style='margin-top:20%;font-size:19px;'>Product Detail</p>
				<ul style='margin-left:3%;margin-top:3%'>";
				$h=0;
				$r=3;
				while($h<=$u-1)
				{
					$detail=$data['detail'.$r];
					echo "<li style='margin-top:1%'>$detail</li>";
					$h++;
					$r++;
				}
			
			echo	"</ul></div></div>";
		}
 			?>





			<hr style="margin-right: 1%;width: 900px;margin-left: 2%;width: 97%">



			
		<h1 style="margin-left:2%;margin-top: 2%">Company Info:</h1>
		<div>
			<div style="margin-top: 5%;float: left;">
				<img src="img/zara.jpg" style="width: 30%;float: left;">
				<h1 style="margin-left: 3%">XYZ</h1>
				<p style="margin-left:2%;margin-top: 4%;float: left;">Zaranet network 14G, jalan pandan indah 1/23c,Pandan indah, 55100, Kuala Lumpur, Malaysia.</p>
				<p style="margin-top: 1%;margin-left: 2%;float: left;">Contact Info:+60 16 656 1067</p>
			</div>
		</div>
			
			</div> 
			<hr style="margin-top: 24%;margin-right: 1%;margin-left: 1%">
			<div style="margin-left: 2%;margin-top: 2%">			
				<h1>Comment</h1>
				
					<form method="post" class="form" enctype="multipart/form-data" action="action_page1.php">
							<div >
							<input type="txt" style="width: 60%;padding: 3px 7px;margin-top: 1%;float: left;" name="Comment">
							<ul class="Comment" style="list-style-type: none;font-size: 12px;margin-left: 5%;color: red;margin-top: 2%"></ul>				
							<button style="width: 5%;height: 25px;margin-left: 0%;float: left;margin-top: 1%;">Comment</button>
							</div>
					</form>
				
				<br>
			
			</div>

			<?php  
				$str = "select * from `{$j}{$k}`";
				
				// echo $str;
				$result = $conn->query($str) or die($conn->error);
				$i=0;
				if($result->num_rows > 0){
				
					while($data = $result->fetch_array(MYSQLI_ASSOC)) 
					{	
						$date=$data['date'];	
						if($i==0)
						{    echo '<br>';
					 		echo '<br>';
					  		echo '<br>';
					  		$id_comment=$data['id'];
					  		
					  		if($id_comment=='Asifmamu')
					  		{
					  			$Name='Zaranet';
					  		}
					  		else
					  		{
					  			$str1="select * from registration where id=$id_comment";
								$result1 = $conn->query($str1) or die($conn->error);
								$data1 = $result1->fetch_array(MYSQLI_ASSOC);
								$first=$data1['first_name'];
								$last=$data1['last_name'];
								$arr = array($first,$last);
								$Name= join(" ",$arr);
							}
					  		echo "<div style='margin-bottom:3.4%;margin-left:2%'><i class='fa fa-user-circle' style='float:left;font-size:224%'></i><p style='float:left;margin-top:0.8%;margin-left:1%'>$Name</p><p style='float:left;margin-top:1%;margin-left:2.4%;font-size:11px'>$date</p></div>";
							echo '<div class="comment1" style="margin-top:0.3% !important;margin-left:2.2%">';
								echo $data['comment'];
								echo "<br>";
							echo "</div>";
							$i++;
						}
						else
						{
							$id_comment=$data['id'];
					  		if($id_comment=='Asifmamu')
					  		{
					  			$Name='Zaranet';
					  		}
					  		else
					  		{
					  			$str1="select * from registration where id=$id_comment";
								$result1 = $conn->query($str1) or die($conn->error);
								$data1 = $result1->fetch_array(MYSQLI_ASSOC);
								$first=$data1['first_name'];
								$last=$data1['last_name'];
								$arr = array($first,$last);
								$Name= join(" ",$arr);
							}
					  		echo "<div style='margin-bottom:4%;margin-left:2%;margin-top:1.4%;margin-bottom:5%'><i class='fa fa-user-circle' style='float:left;font-size:224%'></i><p style='float:left;margin-top:0.8%;margin-left:1%'>$Name</p><p style='float:left;margin-top:1%;margin-left:2.4%;font-size:11px'>$date</p></div>";
							echo '<div class="comment1" style="margin-top:3% !important;margin-left:2.2%">';
								echo $data['comment'];
								echo "<br>";
							echo "</div>";		
						}
					}
				}
			?>
			<style type="text/css">
				.comment1{
					padding-left: 
				}
			</style>

			<hr style="margin-top: 0.8%;margin-right: 1%;margin-left: 1%">
			<div style="width: 100%;height: 40px;margin-top: 4%" >
					<button style="width: 100%;height: 40px; background-color: #37475A;border:0px;color: white" class="btn_back_to_top">
					Back to Top
					</button>
			</div>
		<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.0.min.js"></script>
		<script>

		$(function(){
			
	  	$(".btn_back_to_top").click(function(){
	  		//$(window) =>animate NO
	  		$("html").animate({
	  			"scrollTop":0
	  		},0.000000000000000000000000000000001);
	  	});
	  	$(window).scroll(function(){
	  		// console.log( $(window).scrollTop() );
	  		if($(window).scrollTop() > 0){
	  			$(".header").css({
	  				"position":"fixed",
	  				"top":0,
	  				
	  			});
	  			//$(".right_div").fadeIn(400);
	  		}
	  		else{
				$(".header").css({
	  				"position":"static",
	  				"margin":"auto"
	  			});
	  			//$(".right_div").fadeOut(400);
	  		}
	  	});
		})
	</script>
			<?php
			include("footer.php")
			?>
	
</body>
</html>

