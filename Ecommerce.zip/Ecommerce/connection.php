<?php  
	/*
		//C:\xampp\php\php.ini
		//C:\xampp\php\ext\php_mysqli.dll
		php.net => mysqli

		hostname,user,password,database

		localhost/phpmyadmin => mysql db=>user table
	*/
	$conn = new mysqli("localhost","root","","ecommerce");
	// echo "<pre>";
	// print_r($conn);
	// echo "</pre>";
?>