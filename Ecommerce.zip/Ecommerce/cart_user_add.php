<?php
	require('connection.php');
	 ob_start(); 
	if(!isset($_COOKIE['id']))
	{
		header('location:login.php');
	}
	$id_user_id=$_COOKIE['id'];
	$str="select * from registration where id='$id_user_id'";
	$result = $conn->query($str) or die($conn->error);
    $data = $result->fetch_array(MYSQLI_ASSOC);
    $phone_number=$data['phone_number'];
         
	$str="select * from `{$phone_number}_cookies`";
    $result = $conn->query($str) or die($conn->error);
    if($result->num_rows > 0){
        
    	while($data = $result->fetch_array(MYSQLI_ASSOC)) 
    	{

    		$id=$data['id'];

    		if(isset($_REQUEST['value'.$id]))
    		{
    			$ans=$_REQUEST['value'.$id];
    			
    			$ext = strrchr($ans, "?");
    			
    			$et = strrchr($ext, "&");
    		
    			$k=substr($et,3);
    			
    			$extn=strlen($et);
    			
    			$extnq=substr($ext,0,-$extn);
    			
    			$j=substr($extnq,3);
    			
    			$id1=$_COOKIE['id'];

    			$str1="insert into order1 (j,k,id_name,a,b,c,d) values ('$j','$k','$id1',0,0,0,0)";
    			$result1 = $conn->query($str1) or die($conn->error);

    		}
    	}
	}
	header('location:order.php')
?>