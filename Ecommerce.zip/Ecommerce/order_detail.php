<?php
	session_start();
	require('connection.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="layout1.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>
<?php
	session_regenerate_id(true);
	unset($_SESSION['j_for_select']);
	session_regenerate_id(true);
	unset($_SESSION['k_for_product']);
?>
	<style type="text/css">
		.circle {
    background: lightblue;
    border-radius: 50%;
    width: 12px;
    height: 12px;
    margin-left:12%;
    margin-top: 15%;
    z-index: 222;
}
.circle3{
	 background: lightblue;
    border-radius: 50%;
    width: 12px;
    height: 12px;
    margin-left:12%;
    margin-top: 0%;
    z-index: 22;
}
.line{
	 width: 1%;
 	 margin-left: 12.3%;
  	 background-color:red;
     margin-top: 15.3%;
     background-color: grey;
     height: 200px;
     position: relative;
     z-index: -2;
}
.line2{
	 width: 1%;
 	 margin-left: 12.3%;
  	 background-color:red;
     margin-top: 0%;
     background-color: grey;
     height: 200px;
     position: relative;
     z-index: -2;
}
.line3{
	 width: 1%;
 	 margin-left: 12.3%;
  	 background-color:red;
     margin-top: 0%;
     background-color: grey;
     height: 200px;
     position: relative;
     z-index: -2;
}
.vertline2 {
  width: 0.5%;
  margin-left: 6.19%;
  background-color:red;
  top: 56.3%;
   position: absolute;
  animation:lineup 3s forwards;
  z-index:-1;
}
.vertline3{
  width: 0.5%;
  margin-left: 6.19%;
  background-color:red;
  top: 86.3%;
   position: absolute;
  animation:lineup 3s forwards;
  z-index:-1;
}
.vertline{
	width: 0.5%;
  margin-left: 6.19%;
  background-color:red;
  top: 25.3%;
   position: absolute;
  animation:lineup 3s forwards;
  z-index:-1;	
}
.circle2{
	 background: lightblue;
    border-radius: 50%;
    width: 12px;
    height: 12px;
    margin-left:12%;
    margin-top: 0%;
    z-index: 22;
}
.circle4{
	 background: lightblue;
    border-radius: 50%;
    width: 12px;
    height: 12px;
    margin-left:12%;
    margin-top: 0%;
    z-index: 22;

}
@keyframes background-fade {
    99.9% {
        background:#E1FEE0;
    }
    100% {
        background:#000;
    }
}
.circle{
    /*display: inline;*/
    animation: background-fade 0s forwards;
}
.circle2{
    /*display: inline;*/
    animation: background-fade 4s forwards;
}
.circle3{
    /*display: inline;*/
    animation: background-fade 7.5s forwards;
}
.circle4{
    /*display: inline;*/
    animation: background-fade 10.5s forwards;
}

@keyframes lineup {
  0% {
    height: 0px;
  }
  100% {
    height: 200px;
  }
}
	</style>
	<?php 
			include("header.php")
	?>
	<?php
		$id=$_GET['user'];
		// echo $id;
		$str2 = "select * from order1 where id='$id'";
		$result2 = $conn->query($str2) or die($conn->error);
		$data3 = $result2->fetch_array(MYSQLI_ASSOC) ;
		$a=$data3['a'];
		$b=$data3['b'];
		$c=$data3['c'];
		$d=$data3['d'];

		echo "<div style='width:100%;margin-bottom:62%''>";
		echo  "<div style='width:50%;float:left'>";
		echo  "<div><div class='circle' style='float:left'></div>
		<p style='float:left;margin-top:15.2%;margin-left:2%'>Order placed<p></div>";
		if($a>0&&$b>0&&$d!=1)
		{
		echo "<div class='line'></div>";
		echo "<div class='vertline'></div>";
		echo  "<div><div class='circle2' style='float:left'></div>
		<p style='float:left;margin-top:0%;margin-left:2%'>Order Confirm<p></div>";
		}
		if($a>0&&$b>1&&$c>0&&$d!=1)
		{	
		echo "<div class='line2'></div>";
		echo "<div class='vertline2' style='display:none'></div>";
		echo  "<div><div class='circle3' style='float:left'></div>
		<p style='float:left;margin-top:0%;margin-left:2%'>Out for Delivery<p></div>";
		}
		if($a>0&&$b>1&&$c>1&&$d!=1)
		{
		echo "<div class='line3'></div>";
		echo "<div class='vertline3' style='display:none'></div>";
		echo  "<div><div class='circle4' style='float:left'></div>
		<p style='float:left;margin-top:0%;margin-left:2%'>Delivered<p></div>";
		}
		if($d==1)
		{
			echo "<div class='line'></div>";
			echo "<div class='vertline'></div>";
			echo  "<div><div class='circle2' style='float:left'></div>
			<p style='float:left;margin-top:0%;margin-left:2%'>Cancelled<p></div>";
		}
		echo "</div>"
	?>
	<?php
		$k=$_GET['k'];
		$j=$_GET['j'];
		if($j==3)
			{
				$str = "select * from hp where id='$k'";
			}
			elseif ($j==4) {
				$str = "select * from dell where id='$k'";
			}
			elseif($j==5){
				$str = "select * from Asus where id='$k'";
			}
			elseif($j==6){
				$str = "select * from apple_macbook where id='$k'";
			}
			elseif($j==7){
				$str = "select * from Lenovo where id='$k'";
			}
			elseif($j==8){
				$str="select * from index_page where id='$k'";
			}
			$result1 = $conn->query($str) or die($conn->error);	
			// var_dump($result);
			
				$data2 = $result1->fetch_array(MYSQLI_ASSOC) ;
				// print_r($data) ;

				$photo=$data2['image'];

				echo "<div style='float:left;width:50%;'><a href='product_view.php?id_index=$j&k=$k'><button style='float:right;margin-top:15%;margin-left:60%;margin-right:10%;background-color:white;border:0'><div class='hover_img'><img src='img/$photo' style='height:400px' ></div></button></a></div></div>";
	?>
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.0.min.js"></script>
		<script>
			$(document).ready(function(){
    		    
   			 	 $(".vertline2").delay(5000).fadeIn();
   			 	  $(".vertline3").delay(8000).fadeIn();

			});			
		</script>
		<style type="text/css">
			.hover_img:hover{
				cursor: pointer;
			}
		</style>
</body>
</html>