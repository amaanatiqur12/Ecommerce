<?php

		
		require 'connection.php';

		
		
		
		$j=1;
     	while($j<=5)
     	{
     		$title="title$j";

     		
     		if(isset($_REQUEST[$title]))
     		{
     			
     			$title= $conn->real_escape_string(strip_tags(trim($_REQUEST[$title])));
     			echo $title;
     			$sql="Update label set title=NULL where id='$j'";
				$result = $conn->query($sql) or die($conn->error);
				//
				$sql="update label set title='$title' where id='$j'";
      			$result = $conn->query($sql) or die($conn->error);	
      			var_dump($result);
     		}
     		$j++;
     	}

	
	 header("location:index_admin.php");	
?>


