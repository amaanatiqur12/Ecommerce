<?php
	session_start();
	require('connection.php');
	$id=$_GET['l'];
	$phone_number=$_SESSION['Identity_database'];
	$str="DELETE FROM `{$phone_number}_cookies` WHERE id='$id'";
	$result = $conn->query($str) or die($conn->error);
	header("location:cart_user.php")
?>