<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php  
		session_start();
		require 'connection.php';

	
			$email = $conn->real_escape_string(strip_tags(trim($_REQUEST['Email_ID'])));
			$password = $conn->real_escape_string(strip_tags(trim($_REQUEST['Password'])));

		
			$str = "select password1 from registration where Email='$email' ";
		// echo $str;

			$result = $conn->query($str) or die($conn->error);
		// print_r($result);

			$ans = $result->fetch_array(MYSQLI_ASSOC);
		print_r($ans);
		$dbapss = $ans['password1'];
			if(is_array($ans) && count($ans)>0 && $password == $dbapss){
				     if($email=='adminecommerce@gmail.com'&&$password=='rootcanacess123')
				     {		     	
			     		session_regenerate_id(true);
						unset($_SESSION['email']);
						//session_destroy();
						setcookie('id_admin',"Asifmamu",time()+3600000000);
						header("location:index_admin.php");     	
				     }
				     else
				     {
				     	
				     	$str = "select id from registration where Email='$email' ";
				     	$result = $conn->query($str) or die($conn->error);
				     	$ans = $result->fetch_array(MYSQLI_ASSOC);
				     	$dbapss = $ans['id'];
				     	setcookie('id',$dbapss,time()+3600000000);

				     	$str = "select phone_number from registration where Email='$email' ";
				     	$result = $conn->query($str) or die($conn->error);
				     	$ans = $result->fetch_array(MYSQLI_ASSOC);
				     	$dbapss = $ans['phone_number'];
				     	
				     	$_SESSION['Identity_database']=$dbapss;
				   		//setcookie("pname","shirt",time()+3600);
				     	session_regenerate_id(true);
						unset($_SESSION['email']);
						//session_destroy();
						header("location:regenerate_file_id_cart.php");
				     }				
				}			
			else{
					$_SESSION['email'] = 5;
					header("location:login.php");
			}
			
			 
	?>
</body>
</html>