<?php
	session_start();
	require('connection.php');
	$id=$_GET['id'];
	$date=date(" j F Y ");
 if(isset($_GET['a']))
 {
 	$str="update order1 set a=1,b=1 where id='$id'";
 	$result = $conn->query($str) or die($conn->error);
 	$str="update order1 set order_conformation='$date' where id='$id'";
 	$result = $conn->query($str) or die($conn->error);	
 }
  if(isset($_GET['b']))
 {
 	$str="update order1 set b=2,c=1 where id='$id'";
 	$result = $conn->query($str) or die($conn->error);
 	$str="update order1 set order_Dispatch='$date' where id='$id'";
 	$result = $conn->query($str) or die($conn->error);		
 }
  if(isset($_GET['c']))
 {
 	$str="update order1 set c=2 where id='$id'";
 	$result = $conn->query($str) or die($conn->error);	
 	$str="update order1 set order_dilever='$date' where id='$id'";
 	$result = $conn->query($str) or die($conn->error);	
 }
 if(isset($_GET['d']))
 {
 	$str="update order1 set d=1 where id='$id'";
 	$result = $conn->query($str) or die($conn->error);	
 	$str="update order1 set order_cancel='$date' where id='$id'";
 	$result = $conn->query($str) or die($conn->error);	
 }
header("location:order_admin.php")
?>