<?php
session_start();
require('connection.php');	
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="layout1.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body style="background-color: 	#F5F5F5;">
	<?php 
            if(!isset($_COOKIE['id']))
            {
                header('location:login.php');
            }
       ?>
		<?php 
			include("header.php")
		?>
		<h1 style="margin-left: 10%;margin-top: 4%">Your Order</h1>
		<?php
        $i=1;
        
       
        $id_user=$_COOKIE['id'];
		$str="select * from order1 where id_name='$id_user'";

        $result = $conn->query($str) or die($conn->error);
       
        if($result->num_rows > 0){
        
        while($data = $result->fetch_array(MYSQLI_ASSOC)) 
        { 

        
        $j=$data['j'];
       
        $k=$data['k'];
        $id=$data['id'] ; 
        $a=$data['a'];
        $b=$data['b'];
        $c=$data['c'];
        $d=$data['d'];
			
			if($j==3)
			{
				$str = "select * from hp where id='$k'";
			}
			elseif ($j==4) {
				$str = "select * from dell where id='$k'";
			}
			elseif($j==5){
				$str = "select * from Asus where id='$k'";
			}
			elseif($j==6){
				$str = "select * from apple_macbook where id='$k'";
			}
			elseif($j==7){
				$str = "select * from Lenovo where id='$k'";
			}
			elseif($j==8){
				$str="select * from index_page where id='$k'";
			}

			

			$result1 = $conn->query($str) or die($conn->error);	
			// var_dump($result);
			
				$data2 = $result1->fetch_array(MYSQLI_ASSOC) ;
				// print_r($data) ;

					$photo=$data2['image'];
					$price=$data2['price'];
					
					$Name=$data2['name'];
		echo "<a href='order_detail.php?j=$j&k=$k&user=$id' method='Post'><button style='border: 0px solid;margin-left: 10%;width: 80%;height:140px;margin-top: 2%;background-color: white !important;border-radius: 12px' class='hover_btn_order'>
			<div style='float: left;margin-top: 2%;margin-left: 3%;width: 20%'>
				<img src='img/$photo' style='width: 60%'>
			</div>
			<div style='float: left;width: 30%'>
				<p style='float: left;font-size: 13px;margin-top: 5%'>$Name</p>
			</div>
			<div style='float: left;margin-top:4.6%;width: 5%'>
				<p style='font-size: 18px;margin-left: 5%'>&#8377;$price</p>
		
			</div><div style='float: left;width: 40%;margin-top: 4.6%;font-size: 17px'>";
		if($a==1&&$b==2&&$c==1&&$d==0)
		{
			echo "<p>Out for Delivery</p>";
		}
		elseif($a==1&&$b==1&&$c==0&&$d==0)
		{
			echo "<p>Order Confirm</p>";
		}
		elseif($a==0&&$b==0&&$c==0&&$d==0)
		{
			echo "<p>Order Placed</p>";
		}
		elseif($a==1&&$b==2&&$c==2)
		{
			echo "<p>Delivered</p>";
		}
		elseif($d==1)
		{
			echo "<p>Cancelled</p>";
		}

		echo 	"</div>";
		echo "</button></a>";
	}
}


		?>
		<div style="margin-bottom: 14%">
			
		</div>	
		<div style="width: 100%;height: 40px;margin-top: 4%" >
					<button style="width: 100%;height: 40px; background-color: #37475A;border:0px;color: white" class="btn_back_to_top">
					Back to Top
					</button>
			</div>
		<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.0.min.js"></script>
		<script>

		$(function(){
			
	  	$(".btn_back_to_top").click(function(){
	  		//$(window) =>animate NO
	  		$("html").animate({
	  			"scrollTop":0
	  		},0.000000000000000000000000000000001);
	  	});
	  	$(window).scroll(function(){
	  		// console.log( $(window).scrollTop() );
	  		if($(window).scrollTop() > 0){
	  			$(".header").css({
	  				"position":"fixed",
	  				"top":0,
	  				
	  			});
	  			//$(".right_div").fadeIn(400);
	  		}
	  		else{
				$(".header").css({
	  				"position":"static",
	  				"margin":"auto"
	  			});
	  			//$(".right_div").fadeOut(400);
	  		}
	  	});
		})
	</script>
	<?php
    include("footer.php");
	?>
		<style type="text/css">
			.hover_btn_order:hover{
				cursor: pointer;
			}
		</style>
</body>
</html>