<?php
	session_start();
	require('connection.php'); 
	$j=$_SESSION['j_for_select'];
	$k=$_SESSION['k_for_product'];
	$id=$_COOKIE['id'];
	$str="insert into order1 (j,k,id_name,a,b,c,d) values ($j,$k,$id,0,0,0,0)"; 
	$result = $conn->query($str) or die($conn->error);
	header('location:payment.php');
?>