<?php
 	session_start();
		require 'connection.php';
		

		$j=$_SESSION['j_for_select'];
		$k=$_SESSION['k_for_product'];
		$date=date(" j F Y ");
		// echo $date;
		$Comment= $conn->real_escape_string(strip_tags(trim($_REQUEST['Comment'])));
		if($Comment=='')
		{
			
			if(isset($_COOKIE['id_admin']))
			{
				header("location:product_view_admin.php");
			}
			elseif(isset($_COOKIE['id'])) {
				header("location:product_view.php");
				}	
		}
		else
		{
			if(isset($_COOKIE['id_admin']))
			{
				$id=$_COOKIE['id_admin'];
				$str = "insert into `{$j}{$k}`(comment,date,id)  values ('$Comment','$date','$id')";
			}
			elseif(isset($_COOKIE['id']))
			{
				$id=$_COOKIE['id'];
				$str = "insert into `{$j}{$k}`(comment,date,id)  values ('$Comment','$date','$id')";
			}
	

			$result = $conn->query($str) or die($conn->error);

			if(isset($_COOKIE['id_admin']))
			{
			header("location:product_view_admin.php");
			}
			elseif(isset($_COOKIE['id'])) {
				header("location:product_view.php");
				}	
		}
?>