<?php
	require('connection.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="layout1.css">
	
</head>
<body style="overflow-x: hidden;">
		<div class="header" style="width: 100%;height: 60px;margin:0;background-color:#1a1a1a;"> 
			<button class="silder_left" style="padding:0px;background: white;border: 1px solid"><img src="img/bar.svg" style="width: 100%;height: 35px;margin: 0;padding: 0;color: white"></button>
			<!-- <button style="float: left;height:0%;width: 9%;border: 0px solid;margin-left: 45%;margin-top: 1.5%;"class="btn_home" onClick="window.location='index.php';">
				<img src="img/zara1.jpg" style="width: 50%">
			</button> -->
			<!-- <button class="silder_left"><img src="img/drop.svg" style="width: 100%;height: 35px;margin: 0;padding: 0"></button> -->
			<!-- <img src="img/symbol_b.jpeg" style="width: 10%;height: 54px;margin-left:1%;float: left" > -->
			<button style="width: 4%;height: 54px;margin-left:1%;float: left;border: 0px"class="btn_home" onClick="window.location='index.php';">
				<img src="img/zara1.jpg" style="width: 100%;height: 54px">
			</button>
			<div style="float: left;width: 50%;margin-top:0.7%">
				<form action="search_page.php" method="post" >
					<input type="txt" style="margin-left: 8%;width: 80%;height: 25px !important;padding:5px 5px !important;float: left;border-top-left-radius:  5px;border-bottom-left-radius: 5px;border: 1px solid" name="search">
					<button style="width: 8%;height: 38px;float: left;cursor: pointer;border:1px solid; "><i class="fa fa-search"></i></button>
				</form>
			</div>
			
			
		
			
			
			<?php 
				if(isset($_COOKIE['id'])){
		
					echo "<form action='cart_user.php'><button  class='cart'  style='color: #cc0000'><i class='fa fa-shopping-cart' style='float: left;font-size: 20px;' class='cart' ></i><h1 style='font-size: 19px;float: left'>Cart</h1></button></form><form action='order.php'><button class='order' style='color: #cc0000'><i class='fa fa-truck' style='float: left;font-size: 20px;'></i><h1 style='font-size: 19px;float: left;' >Order</h1></button></form><form action='logout_page.php'><button  class='order' style='color: #cc0000'><h1 style='font-size: 19px;float: left'>Logout</h1></button></form>";
				}
				else
				{
					echo "<form action='cart.php'><button  class='cart'  style='color: #cc0000'><i class='fa fa-shopping-cart' style='float: left;font-size: 20px;' class='cart' ></i><h1 style='font-size: 19px;float: left'>Cart</h1></button></form><form action='login.php'><button  onclick='window.location='login.php';' class='sign_in' style='color: #cc0000'><h1 style='font-size: 19px;float: left'>Sign in</h1></button></form>";	
				}


			?>
			
		</div>
		<div class="blackbox">
			
		</div>
		<div class="box">
			<!-- <div style="width: 100%;height: 60px;border: 1px solid">
				<div style="border: 1px solid;border-radius:  100%;float: left;"><i class="fa fa-user" style="font-size: 30px;padding-left:  14%"></i></div>
			</div> -->
			<?php
				if(isset($_COOKIE['id'])){
				$id_user=$_COOKIE['id'];
				$str = "select first_name from registration where id=$id_user";
				$result = $conn->query($str) or die($conn->error);
				$ans1 = $result->fetch_array(MYSQLI_ASSOC);
				


				echo "<div style='width: 100%;height: 50px;background-color: #232f3e;'>
				<h1 style='color: white;padding-left: 10%'>Hello , {$ans1['first_name']}</h1></div>";
				}
				else
				{
					echo "<div style='width: 100%;height: 50px;background-color: #232f3e;'>
				<h1 style='color: white;padding-left: 10%'>Hello</h1></div>";	
				}

			?>
			
			<div style="margin-bottom: 7%">
				<h1 style="margin-top: 10%;font-size: 19px;margin-left: 7% ">
					Trending
				</h1>
				
				<a href="search.php?href=1">
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=1';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">Best Sellers</span></button></a>
				<br>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=2';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">New Releases</span></button>
				<hr style="margin-top: 5%">
				<h1 style="margin-top: 4%;font-size: 19px;margin-left: 7% ">
					Brand
				</h1>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=3';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">H P</span></button>
				
				<br>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=4';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">Dell</span></button>
				
				<br>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=5';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">Microsoft</span></button>
				
				<br>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=6';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">Apple</span></button>
				
				<br>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=7';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">Lenovo</span></button>
				
				<hr style="margin-top: 5%">
				<h1 style="margin-top: 4%;font-size: 19px;margin-left: 7% ">
					Other Product
				</h1>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=11';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">Network Components</span></button>
				
				<br>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=9';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">Components</span></button>
				
				<br>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=10';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">Bags</span></button>
			</div>
		</div>
		<style type="text/css">
			.hover_box:hover{
				background-color:#BEBEBE !important; 
			}
			.hover_box{
				cursor: pointer;
			}
		</style>
		<div class="cross_dropleft" >
				<img src="img/times-solid.svg" style="width: 100%;/*background:  white !important;*/z-index: 14;" >
		</div>
		<!-- <div class="cross_signin_modalbox" >
				<img src="img/times-solid.svg" style="width: 122%;/*background:  white !important;*/z-index: 14;" >
		</div> -->
		<!-- <div class="sign_box">
			
		</div> -->
       <!--  <div class="" style="position:absolute;width: 100%;height: 300px; background-image: linear-gradient(to bottom, rgba(300,300,300,0), rgba(300,300,300,1));z-index: 11;top: 47.5%">
        	
        </div> -->
		
		<style type="text/css">
			.header{
			z-index: 969;
			}
			.cart{
				border: 0px solid;
				float: right;
				/*padding: 1% 2.6% !important;*/
				/*margin-right: 1%;*/
			/*	margin-top: 0.6%;*/
				cursor: pointer;
				padding-top:1.4% ;
				padding-bottom:1.4%;
				padding-left:2%;
				padding-right: 2%;
				background-color:#1a1a1a;
			}
			.sign_in{
				border: 0px solid;
				float: right;
				/*padding: 1.6% 2.6% !important;*/
				padding-top:1.4% ;
				padding-bottom:1.4%;
				padding-left:2%;
				padding-right: 2%;
				/*margin-right: 2%;*/
				background-color:#1a1a1a;
				/*margin-left: 4%;*/
				cursor: pointer ;
			}
			.order{
				border: 0px ;
				float: right;
				/*padding: 1.6% 2.6% !important;*/
				padding-top:1.4% ;
				padding-bottom:1.4%;
				padding-left:2%;
				padding-right: 2%;
				/*margin-right: 2%;
				margin-top: 0.6%;*/
				cursor: pointer ;
				background-color:#1a1a1a;
			}
			.cart:hover{
				background-color: #212529 !important;
				color: white !important;
			}
			.order:hover{
				background-color: #212529 !important;
				color: white !important;
			}
			.sign_in:hover{
				background-color: #212529 !important;
				color: white !important;
			}
			.silder_left{
				width:5%;
				height: 40px;
				margin-left: 2%;
				margin-top:0.7%;
				float: left;
				cursor: pointer;

			}
			.blackbox{
				width: 100%;
				height: 100%;
				background-color: rgba(0,0,0,0.5);
				position: fixed;
				z-index:970;
				top: 0%;
				left:0%;
			}
			.box{
				left: -27%;
				top:0%;
				width: 27%;
				height:100%;
				z-index: 971;
				background: #fff;
				position: fixed;
				overflow: auto;
			}
			.cross_dropleft{
				cursor: pointer ;
				background-color: rgba(0,0,0,0.001);
				z-index: 971;
				width: 2%;
				height: 6%;
				position: fixed;
				margin-left: 28%;
				top: 0%;
				left: 0%;
			}
			.cross_dropleft:hover{
					cursor: pointer ;
			}
			
		
		</style>
		<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.0.min.js"></script>

			<script type="text/javascript">
				$(document).ready(function(){
				$(".cross_dropleft,.blackbox,.sign_box,.cross_signin_modalbox").hide();
				

				$(".silder_left").click(function(){

					$(".blackbox").fadeIn(500);
					$(".cross_dropleft").fadeIn(500);
					$(".box").animate({
						"left":"0%"
					},500);
	
				})

				$(".cross_dropleft , .blackbox").click(function(){
					$(".cross_dropleft").fadeOut(1000);
					$(".blackbox").fadeOut(1000);
					$(".box").animate({
						"left":"-27%"
					},500);
				})
				$(".sign_in").click(function(){
					$(".sign_box").fadeIn(10);
				    $(".cross_signin_modalbox").fadeIn(10);
				    $(".blackbox").fadeIn(10);
				})
				$(document).keydown(function(kobj){
			if(kobj.keyCode == 27){
					$(".sign_box").fadeOut(10);
				    $(".cross_signin_modalbox").fadeOut(10);
				    $(".blackbox").fadeOut(10);
				    $(".cross_dropleft").fadeOut(1000);
					$(".blackbox").fadeOut(1000);
					$(".box").animate({
						"left":"-27%"
					},500);
				}
			})
				$(".cross_signin_modalbox , .blackbox").click(function(){
					$(".cross_signin_modalbox").fadeOut(10);
					$(".blackbox").fadeOut(1);
				 	$(".sign_box").fadeOut(10);
				})
				});

			</script>
			
</body>
</html>