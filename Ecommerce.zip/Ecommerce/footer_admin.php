<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
		<div style="width: 100%;height: 600px;background-color: #C5C6C6;"> 
		<div style="width: 30%;height: 400px;float: left;">
			<img src="img/zara1.jpg" style="width:40%;margin-left:14%;margin-top: 10%">
			
				<h1 style="margin-left:12%;font-size: 21px;margin-top: 7%;margin-left:15%">About Us</h1>
				<p style="margin-left:12%;font-size: 14px;margin-top: 2%;margin-left:14%">Providing customer service related to<br> electronic devices.</p>
				
				<h1 style="margin-left:12%;font-size: 21px;margin-top: 7%;margin-left:15%">Contact Us</h1>
				<div>
					<i class="fa fa-phone-volume" style="color: black;margin-left: 15%;margin-top: 3%;float: left;"></i>
					<p style="float: left;margin-top: 3%;margin-left: 5%">+60 16 656 1067</p>
				</div>	
				<br>
				<div style="margin-top:7%;margin-left: 14%;">
					<i class="fa fa-envelope" style="color: black;margin-left: 1%;margin-top: 2%;float: left;"></i>
					<p style="float: left;margin-top:1%;margin-left: 4%;margin-bottom: 2%">ansari@gmail.com</p>
				</div>
		</div>
		<div style="width: 16%;height: 400px;float: left;">
			<h1 style="font-size: 20px;margin-top: 60%;margin-left: 15%;color: black">Information</h1>
			<p style="margin-top: 4%;margin-left:8%"><a href="#" style="text-decoration: none;margin-left:8%;color:black">About us</a><p>
			<p  style="margin-top: 2%;margin-left:5%"><a href="#" style="text-decoration: none;margin-left: 11%;color: black">More search</a></p>
			
			<p style="margin-top: 2%;margin-left:13%"><a href="#" style="text-decoration: none;margin-left:3%;margin-top: 12%;color: black">Blog</a></p>
		
			<p style="margin-top: 2%;margin-left:5%"><a href="#" style="text-decoration: none;margin-left: 11%;margin-top: 12%;color: black">Testimorials</a></p>
			
			<p style="margin-top: 2%;margin-left:11%"> <a href="#" style="text-decoration: none;margin-left: 6%;margin-top: 12%;color: black">Events</a></p>
		</div>
		<div  style="width: 25%;height: 400px;float: left;">
			<h1 style="font-size: 20px;margin-top: 39%;margin-left: 15%;color: black">Helpful Links</h1>
			<p style="margin-top: 4%;margin-left:1%"><a href="#" style="text-decoration: none;margin-left: 15%;color: black">Services</a><p>
			<p  style="margin-top: 2%;margin-left:16%"><a href="#" style="text-decoration: none;color: black">Supports</a></p>
			
			<p style="margin-top: 2%;margin-left:14%"><a href="#" style="text-decoration: none;margin-left: 2.5%;margin-top: 12%;color: black">Terms&Condition</a></p>
		
			<p style="margin-top: 2%;margin-left:3%"><a href="#" style="text-decoration: none;margin-left: 14%;margin-top: 12%;color: black">Privacy Policy</a></p>
			
			
		</div>
		<div style="width: 25%;height: 400px;float: left;margin-bottom: 4%">
			<h1 style="font-size: 17px;margin-top: 49%">Subscribe More Info</h1>
			<input type="txt" placeholder="Enter your Email" style="margin-top: 6%;padding: 13px 5px;border-radius: 5px;border:1px solid;width: 65%;background-image: url(img/envelope.svg);background-repeat: no-repeat;background-position:8px;padding-left:40px;background-size: 7%">
			<br>

			<button style="margin-top: 5%;padding: 7px 15px;border-radius: 5px;border: 1px solid">Subscribe</button>	
		</div>
		<!-- <div style="width: 27%;height: 400px;background: red;margin-top: 0%">
			<h1>About Us</h1>
		</div> -->
		<!-- <div style="width: 25%;height: 400px;background: yellow;float: left;">
			
		</div> -->
		<div style="height: 150px;width: 100%;background-color: #C5C6C6;"> 
		<hr style="margin-left: 5%;width: 90%;height: 4px;border: 1.5px solid black;background-color: black;border-radius: 16px">
		<div style="width: 100%;margin-top: 0%;">
			<i class="fab fa-facebook" style="font-size:23px;margin-left: 46%;margin-top: 3%"></i>
			<i class="fab fa-twitter" style="font-size:23px"></i>
			<i class="fab fa-google-plus-g" style="font-size:23px"></i>
			<i class="fab fa-instagram" style="font-size:23px"></i>
			<p style="margin-left: 40%;margin-top: 2%">2020 &#169; company.Ltd. All Right reserved</p>
		</div>
		
	</div>
	</div>
	
</body>
</html>