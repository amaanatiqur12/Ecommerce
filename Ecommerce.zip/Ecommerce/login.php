<?php
	session_start();
	if(isset($_SESSION['email'])){
		$i=8;
	}
	else
	{
		$i=1;
	}
?>	
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="layout1.css">
</head>
<body>
		<div style="width: 100%;height:90px;background-color:#1a1a1a" >
			<button style="float: left;height:0%;width: 9%;border: 0px solid;margin-left: 45%;margin-top: 1.5%;"class="btn_home" onClick="window.location='index.php';">
				<img src="img/zara1.jpg" style="width: 50%">
			</button>
		</div>
		<diV style="margin-left:15%;margin-top: 4%;font-size: 18px">
			<h1>Please sign in.</h1>
		<?php
		if($i==1)
		{	
		echo '<form action="login_page.php" method="post" class="form">	
			<input type="txt" style="padding: 10px 5px;width:33%;border-radius: 5px;border:1px solid;margin-top: 4%;font-size: 17px" placeholder="Email ID" name="Email_ID" class="Email_ID">
			<ul class="Email_check " style="  list-style-type: none;font-size: 12px;color: red;margin-top: 1%"></ul>
			<br>
			<input type="Password" style="padding: 10px 5px;width:33%;border-radius: 5px;border:1px solid;margin-top: 1.6%;font-size: 17px" placeholder="Password" name="Password" class="Password">
			<ul class="Password_check" style="  list-style-type: none;font-size: 12px;color: red;margin-top: 1%"></ul>
			<p style="font-size:15px;margin-top: 2%">By continuing, you agree to lemontree<a href="#" style="text-decoration: none;color: #06c;"> Conditions of<br> Use </a>and <a href="#" style="text-decoration: none;color: #06c;">Privacy Notice </a>. Need help?</p>			
			<button style="margin-top: 3%; background: #0071e3;border: 1px solid;width: 34%;height: 60px;color: white;border-radius: 7px;font-size: 18px" class="btn_signin">Sign In</button>
		</form>';
		}
		else
		{
			echo '<form action="login_page.php" method="post" class="form">	
			<input type="txt" style="padding: 10px 5px;width:33%;border-radius: 5px; border:1px solid red !important;margin-top: 4%;font-size: 17px" placeholder="Email ID" name="Email_ID" class="Email_ID">
			
			<br>
			<input type="Password" style="padding: 10px 5px;width:33%;border-radius: 5px; border:1px solid red !important;margin-top: 1.6%;font-size: 17px" placeholder="Password" name="Password"  class="Password">
			<ul  style="  list-style-type: none;font-size: 12px;color: red;margin-top: 1%">
				<li><i class="fa fa-exclamation-circle" style="margin-right:0.4%"></i>Username and password not match</li>
			</ul>
			<p style="font-size:15px;margin-top: 2%">By continuing, you agree to lemontree<a href="#" style="text-decoration: none;color: #06c;"> Conditions of<br> Use </a>and <a href="#" style="text-decoration: none;color: #06c;">Privacy Notice </a>. Need help?</p>			
			<button style="margin-top: 3%; background: #0071e3;border: 1px solid;width: 34%;height: 60px;color: white;border-radius: 7px;font-size: 18px" class="btn_signin">Sign In</button>
		</form>';
		}
		?>
			<br>
			<p style="margin-top: 2%;"><a href="#" style="text-decoration: none;color: #06c;">Forgot your password?</a></p>
			<br>
			<p ><a href="registration.php" style="text-decoration: none;color: #06c;">Don't have an Account? Create one now.</a></p>
		</div>
		<hr style="margin-top: 5%;">
		<p style=";margin-left:15%;margin-top: 2%;margin-bottom: 2%">Need some help?Contact Info:+60 16 656 1067</p>
		<div style="width: 100%;height: 110px;background-color: #f5f5f7;">
			<p style="font-size: 12px;color: #86868b;margin-left: 15%;padding-top: 1.4%">Zaranet network 14G, jalan pandan indah 1/23c,Pandan indah, 55100, Kuala Lumpur, Malaysia. <a href="#" style="color: #515154;text-decoration: none"> Security Policy</a>.</p>
			<hr style="margin-top: 1.5%;width: 70%;margin-left: 15%">
		</div>
		<style type="text/css" >
			.btn_home:hover{
				cursor: pointer;
				border: 0px solid;
			}
			.btn_signin:hover{
				cursor: pointer;
				border: 0px solid;
			}
			.error{
            border:1px solid red !important;
         }
		</style>
		<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.0.min.js"></script>
		<script type="text/javascript">
			$('.form').on('submit', function() {
				
			Email_input=$(".Email_ID").val();
            Email_varaible=/^[a-zA-Z0-9]([a-zA-Z0-9\.]+)?[a-zA-Z0-9]@gmail.com$/
            Email_check=Email_varaible.test(Email_input);
            console.log(Email_check)
            x=0
            if(Email_check==false)
            {
               
               x=1;
               $(".Email_ID").addClass("error")
               str=`<li><i class="fa fa-exclamation-circle" style="margin-right:0.4%"></i>Enter a valid Email address</li>`;
               $(".Email_check").empty();
               $(".Email_check").append(str);
            }
            else
            {
               $(".Email_ID").removeClass("error") 
               $(".Email_check").empty();    
            }
             $(".Email_ID").keyup(function(){
                  $(".Email_ID").removeClass("error") 
                  $(".Email_check").empty();    
            });
             y=0;     
            Password_input=$(".Password").val();
            Password_varaible=/^([a-zA-Z0-9\.\@\&\!]{4,64})$/;
            Password_check=Password_varaible.test(Password_input);
            console.log(Password_check)
            if(Password_check==false)
            {
               y=1;
               $(".Password").addClass("error")
               str=`<li><i class="fa fa-exclamation-circle" style="margin-right:0.8%"></i>Enter your password</li>`;
               $(".Password_check").empty();
               $(".Password_check").append(str);   
               
            }
            else
            {
               $(".Password").removeClass("error")
               $(".Password_check").empty();
            }
            $(".Password").keyup(function(){
                  $(".Password").removeClass("error") 
                  $(".Password_check").empty();    
            });

         
           
              if(x==0&&y==0)
             {
                  return true
             }
             else
             {
                  return false
             }
         })
		</script>

</body>
</html>