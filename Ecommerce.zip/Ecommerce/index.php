<?php
	session_start();
	require('connection.php');
?>
<?php
	session_regenerate_id(true);
	unset($_SESSION['j_for_select']);
	session_regenerate_id(true);
	unset($_SESSION['k_for_product']);
?>
<?php
	if(isset($_COOKIE['id_admin']))
	{
		header('location:index_admin.php');
	}
	
?>
<!DOCTYPE html>
<html >
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="layout1.css">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="index_responsive.css">
</head>
<body style="overflow-x: hidden;">
	<div class="header" style="width: 100%;height: 60px;margin:0;background-color:#1a1a1a;"> 
			<button class="silder_left" style="padding:0px;background: white;border: 1px solid"><img src="img/bar.svg" style="width: 100%;height: 35px;margin: 0;padding: 0;color: white" ></button>
			<!-- <button style="float: left;height:0%;width: 9%;border: 0px solid;margin-left: 45%;margin-top: 1.5%;"class="btn_home" onClick="window.location='index.php';">
				<img src="img/zara1.jpg" style="width: 50%">
			</button> -->
			<!-- <button class="silder_left"><img src="img/drop.svg" style="width: 100%;height: 35px;margin: 0;padding: 0"></button> -->
			<!-- <img src="img/symbol_b.jpeg" style="width: 10%;height: 54px;margin-left:1%;float: left" > -->
			<button style="width: 4%;height: 54px;margin-left:1%;float: left;border: 0px"class="btn_home" onClick="window.location='index.php';">
				<img src="img/zara1.jpg" style="width: 100%;height: 54px">
			</button>

			<div style="float: left;width: 50%;margin-top:0.7%" class="seach_bar">
				<form action="search_page.php" method="post">
					<input type="txt" style="margin-left: 8%;width: 80%;height: 37px !important;padding:5px 5px !important;float: left;border-top-left-radius:  5px;border-bottom-left-radius: 5px;border: 1px solid" name="search">
					<button style="width: 8%;height: 38px;float: left;cursor: pointer;border:1px solid; "><i class="fa fa-search"></i></button>
				</form>
			</div>
			
			
		
			
			
			<?php 
				if(isset($_COOKIE['id'])){
		
					echo "<form action='cart_user.php'><button  class='cart'  style='color: #cc0000'><i class='fa fa-shopping-cart' style='float: left;font-size: 20px;' class='cart' ></i><h1 style='font-size: 19px;float: left'>Cart</h1></button></form><form action='order.php'><button class='order' style='color: #cc0000'><i class='fa fa-truck' style='float: left;font-size: 20px;'></i><h1 style='font-size: 19px;float: left;' >Order</h1></button></form><form action='logout_page.php'><button  class='order' style='color: #cc0000'><h1 style='font-size: 19px;float: left'>Logout</h1></button></form>";
				}
				else
				{
					echo "<form action='cart.php'><button  class='cart'  style='color: #cc0000'><i class='fa fa-shopping-cart' style='float: left;font-size: 20px;' class='cart' ></i><h1 style='font-size: 19px;float: left'>Cart</h1></button></form><form action='login.php'><button  onclick='window.location='login.php';' class='sign_in' style='color: #cc0000'><h1 style='font-size: 19px;float: left'>Sign in</h1></button></form>";	
				}


			?>	
			
		</div>
		<div class="blackbox">
			
		</div>
		<div class="box">
			<!-- <div style="width: 100%;height: 60px;border: 1px solid">
				<div style="border: 1px solid;border-radius:  100%;float: left;"><i class="fa fa-user" style="font-size: 30px;padding-left:  14%"></i></div>
			</div> -->
			<?php
				if(isset($_COOKIE['id'])){
				$id_user=$_COOKIE['id'];
				$str = "select first_name from registration where id=$id_user";
				$result = $conn->query($str) or die($conn->error);
				$ans1 = $result->fetch_array(MYSQLI_ASSOC);
				


				echo "<div style='width: 100%;height: 50px;background-color: #232f3e;'>
				<h1 style='color: white;padding-left: 10%'>Hello , {$ans1['first_name']}</h1></div>";
				}
				else
				{
					echo "<div style='width: 100%;height: 50px;background-color: #232f3e;'>
				<h1 style='color: white;padding-left: 10%'>Hello</h1></div>";	
				}

			?>
			
			<div style="margin-bottom: 7%">
				<h1 style="margin-top: 10%;font-size: 19px;margin-left: 7% ">
					Trending
				</h1>
				
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=1';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">Best Sellers</span></button>
				<br>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=2';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">New Releases</span></button>
				<hr style="margin-top: 5%">
				<h1 style="margin-top: 4%;font-size: 19px;margin-left: 7% ">
					Brand
				</h1>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=3';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">H P</span></button>
				
				<br>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=4';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">Dell</span></button>
				
				<br>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=5';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">Microsoft</span></button>
				
				<br>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=6';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">Apple</span></button>
				
				<br>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=7';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">Lenovo</span></button>
				
				<hr style="margin-top: 5%">
				<h1 style="margin-top: 4%;font-size: 19px;margin-left: 7% ">
					Other Product
				</h1>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=11';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">Network Components</span></button>
				
				<br>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=9';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">Components</span></button>
				
				<br>
				<button style="width: 100%;background-color: white;border:0px" class="hover_box" onClick="window.location='search.php?href=10';"><span style="float: left;padding-left: 7%;padding-bottom: 4%;padding-top: 4%">Bags</span></button>
				
			</div>
		</div>
		<style type="text/css">
			.hover_box:hover{
				background-color:#BEBEBE !important; 
			}
			.hover_box{
				cursor: pointer;
			}
		</style>
		<div class="cross_dropleft" >
				<img src="img/times-solid.svg" style="width: 100%;/*background:  white !important;*/z-index: 14;" >
		</div>
		<!-- <div class="cross_signin_modalbox" >
				<img src="img/times-solid.svg" style="width: 122%;/*background:  white !important;*/z-index: 14;" >
		</div> -->
		<!-- <div class="sign_box">
			
		</div> -->
       <!--  <div class="" style="position:absolute;width: 100%;height: 300px; background-image: linear-gradient(to bottom, rgba(300,300,300,0), rgba(300,300,300,1));z-index: 11;top: 47.5%">
        	
        </div> -->
		
		<style type="text/css">
			.header{
			z-index: 969;
			}
			.cart{
				border: 0px solid;
				float: right;
				/*padding: 1% 2.6% !important;*/
				/*margin-right: 1%;*/
			/*	margin-top: 0.6%;*/
				cursor: pointer;
				padding-top:1.1% ;
				padding-bottom:1.1%;
				padding-left:2%;
				padding-right: 2%;
				background-color:#1a1a1a;
			}
			.sign_in{
				border: 0px solid;
				float: right;
				/*padding: 1.6% 2.6% !important;*/
				padding-top:1.1% ;
				padding-bottom:1.1%;
				padding-left:2%;
				padding-right: 2%;
				/*margin-right: 2%;*/
				background-color:#1a1a1a;
				/*margin-left: 4%;*/
				cursor: pointer ;
			}
			.order{
				border: 0px ;
				float: right;
				/*padding: 1.6% 2.6% !important;*/
				padding-top:1.1% ;
				padding-bottom:1.1%;
				padding-left:2%;
				padding-right: 2%;
				/*margin-right: 2%;
				margin-top: 0.6%;*/
				cursor: pointer ;
				background-color:#1a1a1a;
			}
			.cart:hover{
				background-color: #212529 !important;
				color: white !important;
			}
			.order:hover{
				background-color: #212529 !important;
				color: white !important;
			}
			.sign_in:hover{
				background-color: #212529 !important;
				color: white !important;
			}
			.silder_left{
				width:5%;
				height: 40px;
				margin-left: 2%;
				margin-top:0.7%;
				float: left;
				cursor: pointer;

			}
			.blackbox{
				width: 100%;
				height: 100%;
				background-color: rgba(0,0,0,0.5);
				position: fixed;
				z-index:970;
				top: 0%;
				left:0%;
			}
			.box{
				left: -27%;
				top:0%;
				width: 27%;
				height:100%;
				z-index: 971;
				background: #fff;
				position: fixed;
				overflow: auto;
			}
			.cross_dropleft{
				cursor: pointer ;
				background-color: rgba(0,0,0,0.001);
				z-index: 971;
				width: 2%;
				height: 6%;
				position: fixed;
				margin-left: 28%;
				top: 0%;
				left: 0%;
			}
			.cross_dropleft:hover{
					cursor: pointer ;
			}
			/*.sign_box{
				width: 50%;
				height: 79%;
				z-index: 13;
				background: black;
				position: fixed;
				top: 10%;
				left: 26%;

			}*/
			/*.cross_signin_modalbox{
				cursor: pointer ;
				background-color: rgba(0,0,0,0.001);
				z-index: 13;
				width: 2%;
				height: 6%;
				position: fixed;
				margin-left: 77%;
				top: 10%;
				left: 0%;
			}*/
		
		</style>
		<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.0.min.js"></script>

			<script type="text/javascript">
				$(document).ready(function(){
				$(".cross_dropleft,.blackbox,.sign_box,.cross_signin_modalbox").hide();
				

				$(".silder_left").click(function(){

					$(".blackbox").fadeIn(500);
					$(".cross_dropleft").fadeIn(500);
					$(".box").animate({
						"left":"0%"
					},500);
	
				})

				$(".cross_dropleft , .blackbox").click(function(){
					$(".cross_dropleft").fadeOut(1000);
					$(".blackbox").fadeOut(1000);
					$(".box").animate({
						"left":"-27%"
					},500);
				})
				$(".sign_in").click(function(){
					$(".sign_box").fadeIn(10);
				    $(".cross_signin_modalbox").fadeIn(10);
				    $(".blackbox").fadeIn(10);
				})
				$(document).keydown(function(kobj){
			if(kobj.keyCode == 27){
					$(".sign_box").fadeOut(10);
				    $(".cross_signin_modalbox").fadeOut(10);
				    $(".blackbox").fadeOut(10);
				    $(".cross_dropleft").fadeOut(1000);
					$(".blackbox").fadeOut(1000);
					$(".box").animate({
						"left":"-27%"
					},500);
				}
			})
				$(".cross_signin_modalbox , .blackbox").click(function(){
					$(".cross_signin_modalbox").fadeOut(10);
					$(".blackbox").fadeOut(1);
				 	$(".sign_box").fadeOut(10);
				})
				});

			</script>
			
	
	<div>
		<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel" >
  			<div class="carousel-inner">
    		<div class="carousel-item active" style="height: 500px">
     		 	<img src="img/slider1.jpg" class="d-block w-100" alt="..." style="height: 500px">
    		</div>
    		<div class="carousel-item"  style="height: 500px">
      			<img src="img/slider2.jpg" class="d-block w-100" alt="..." style="height: 500px">
    		</div>
    		<div class="carousel-item"  style="height: 500px">
      			<img src="img/slider3.jpg" class="d-block w-100" alt="..." style="height: 500px">
    		</div>
  			</div>
 			 <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-bs-slide="prev">
    			<span class="carousel-control-prev-icon" aria-hidden="true"></span>
    			<span class="visually-hidden">Previous</span>
  			</a>
  			<a class="carousel-control-next" href="#carouselExampleControls" role="button" data-bs-slide="next">
   	 			<span class="carousel-control-next-icon" aria-hidden="true"></span>
    			<span class="visually-hidden">Next</span>
		 		 </a>
		</div>
	</div>

<!-- <div style="margin-top:35%">
	<div style="width: 20%;height: 350px;float: left;background:black;margin-left: 3%">
	</div>
	<div style="width: 20%;height: 350px;float: left;background: black;margin-left: 3%">
	</div>
	<div style="width: 20%;height: 350px;float: left;background: black;margin-left: 3%">
	</div>
	<div style="float: left;width: 29%;height: 250px;margin-left:2%">
		<div style="width: 90%;height: 150px;background: black;margin-left: 3%;margin-bottom: 1%">
		</div>
		<div style="width: 90%;height: 180px;background: black;margin-left: 3%">
		</div>
	</div>
</div> -->
<div style="margin-top:10%;margin-bottom: 14%">
	<?php  
			
				$str = "select * from label where id=1";
			$result = $conn->query($str) or die($conn->error);	
			$data = $result->fetch_array(MYSQLI_ASSOC);
			$label=$data['title'];
			
				 
			$i=0;
	echo "<div  ><p style='font-size:32px;margin-left:5%;margin-bottom:3%;float:left'>$label</p></div><div style='padding-top:7%'></div>";	


	$str = "select * from index_page";

			$result = $conn->query($str) or die($conn->error);	
			// print_r($result);
			$i=0;
			if($result->num_rows > 0){
				while($data = $result->fetch_array(MYSQLI_ASSOC)) 
				{
					
					$photo=$data['image'];
					$price=$data['price'];
					$Name=$data['name'];
					$i++;
					if($i<=5)
					{
					echo "	<div style='width: 16%;height: 350px;float: left;margin-left: 3%'>
							<img src='img/$photo' style='width: 100%;height: 200px'>
							<a href='product_view.php?id_index=8&k=$i' style='text-decoration: none;color: black' class='mask_hover'>$Name</a>
							<p style='padding-left: 40%'><span>&#8377;</span>$price</p>	
							
							</div>";	
					}
				}
		}
				?>
		<?php  
				$str = "select * from label where id=2";
			$result = $conn->query($str) or die($conn->error);	
			$data = $result->fetch_array(MYSQLI_ASSOC);
			$label=$data['title'];
			
				 
			$i=0;
	echo "<div  ><p style='font-size:32px;margin-left:5%;margin-bottom:3%;float:left'>$label</p></div><div style='padding-top:34%'></div>";		

			

	$str = "select * from index_page";

			$result = $conn->query($str) or die($conn->error);	
			// print_r($result);
			$i=0;
			if($result->num_rows > 0){
				while($data = $result->fetch_array(MYSQLI_ASSOC)) 
				{
					
					$photo=$data['image'];
					$price=$data['price'];
					$Name=$data['name'];
					$i++;
					if($i>=6&&$i<=10)
					{
					echo "	<div style='width: 16%;height: 350px;float: left;margin-left: 3%'>
							<img src='img/$photo' style='width: 100%;height: 200px'>
							<a href='product_view.php?id_index=8&k=$i' style='text-decoration: none;color: black' class='mask_hover'>$Name</a>
							<p style='padding-left: 40%'><span>&#8377;</span>$price</p>	
						
							</div>";	
					}
					}
				}
				?>
					<?php  
			
			
						$str = "select * from label where id=3";
			$result = $conn->query($str) or die($conn->error);	
			$data = $result->fetch_array(MYSQLI_ASSOC);
			$label=$data['title'];
			
				 
			$i=0;
	echo "<div  ><p style='font-size:32px;margin-left:5%;margin-bottom:3%;float:left'>$label</p></div><div style='padding-top:34%'></div>";		

	$str = "select * from index_page";

			$result = $conn->query($str) or die($conn->error);	
			// print_r($result);
			$i=0;
			if($result->num_rows > 0){
				while($data = $result->fetch_array(MYSQLI_ASSOC)) 
				{
					
					$photo=$data['image'];
					$price=$data['price'];
					$Name=$data['name'];
					$i++;
					if($i>=11&&$i<=15)
					{
					echo "	<div style='width: 16%;height: 350px;float: left;margin-left: 3%'>
							<img src='img/$photo' style='width: 100%;height: 200px'>
							<a href='product_view.php?id_index=8&k=$i' style='text-decoration: none;color: black' class='mask_hover'>$Name</a>
							<p style='padding-left: 40%'><span>&#8377;</span>$price</p>	
							</div>";	
					}
					}
				}
				?>
					<?php  
			
				$str = "select * from label where id=4";
			$result = $conn->query($str) or die($conn->error);	
			$data = $result->fetch_array(MYSQLI_ASSOC);
			$label=$data['title'];
			
				 
			$i=0;
	echo "<div  ><p style='font-size:32px;margin-left:5%;margin-bottom:3%;float:left'>$label</p></div><div style='padding-top:34%'></div>";		


	$str = "select * from index_page";

			$result = $conn->query($str) or die($conn->error);	
			// print_r($result);
			$i=0;
			if($result->num_rows > 0){
				while($data = $result->fetch_array(MYSQLI_ASSOC)) 
				{
					
					$photo=$data['image'];
					$price=$data['price'];
					$Name=$data['name'];
					$i++;
					if($i>=16&&$i<=20)
					{
					echo "	<div style='width: 16%;height: 350px;float: left;margin-left: 3%'>
							<img src='img/$photo' style='width: 100%;height: 200px'>
							<a href='product_view.php?id_index=8&k=$i' style='text-decoration: none;color: black' class='mask_hover'>$Name</a>
							<p style='padding-left: 40%'><span>&#8377;</span>$price</p>	
							</div>";	
					}
					}
				}
				?>
	

</div>
<div style="width: 100%;height: 40px;margin-top: 40%" >
<button style="width: 100%;height: 40px; background-color: #37475A;border:0px;color: white" class="btn_back_to_top">
	Back to Top
</button>
</div>
	<style type="text/css">
		.gallery{
			width: 600%;
			height: 550px;
			margin: auto;
			position: relative;
			overflow: hidden !important;
		}
		.slider{
			
			/*overflow: hidden !important;width: 100%;*/
			height: 550px;
			
		}
		.slides{
			float: left;
		/*	overflow: hidden !important;*/
		}
		/*.square{
			position: absolute;
			width: 16.667%;
			height: 30px;
			bottom: 20px;
			left: 0px;
			
			text-align: center;
		}
		.square span{
			display: inline-block;
			background: black;
			width: 15px;
			height: 15px;
			border-radius: 10px;
			cursor: pointer;
		}*/
		.right{
			width: 64px;height: 64px;
			position: absolute;
			/*border: 1px solid;*/
		    	
		    	
		    z-index: 15;
			left:15%;
			top: 25%;
			cursor: pointer;
		}
		.left{
			width: 64px;height: 64px;
			position: absolute;
			/*border: 1px solid;*/
			left:1%;
			z-index: 5;
			top: 25%;
			cursor: pointer;
		}
		.btn_back_to_top{
			cursor: pointer;
		}
		span {
  			content: "\20B9";
		}
		.mask_hover:hover{
			color: blue !important; 
		}
	</style>
		<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.0.min.js"></script>
		<script>

		$(function(){
			
	  	$(".btn_back_to_top").click(function(){
	  		//$(window) =>animate NO
	  		$("html").animate({
	  			"scrollTop":0
	  		},0.000000000000000000000000000000001);
	  	});
	  	$(window).scroll(function(){
	  		// console.log( $(window).scrollTop() );
	  		if($(window).scrollTop() > 0){
	  			$(".header").css({
	  				"position":"fixed",
	  				"top":0,
	  				
	  			});
	  			//$(".right_div").fadeIn(400);
	  		}
	  		else{
				$(".header").css({
	  				"position":"static",
	  				"margin":"auto"
	  			});
	  			//$(".right_div").fadeOut(400);
	  		}
	  	});
		})
	</script>
	<?php 
		include("footer.php");
		
	?>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
</body>
</html>