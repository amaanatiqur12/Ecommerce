<?php
	    session_start();
		require 'connection.php';
		$img=$_FILES['file']["name"];
		move_uploaded_file($_FILES['file']["tmp_name"],
      			"img/" . $_FILES['file']["name"]);



		$name = $conn->real_escape_string(strip_tags(trim($_REQUEST['name'])));
		$price = $conn->real_escape_string(strip_tags(trim($_REQUEST['price'])));
		
		$j = $_SESSION['href'];

		
		$count=$_GET['count'];
		$i=3;
		// }
		if($j==3)
			{
				$str="insert into hp  (name,price,image) values ('$name','$price','$img') ";
				$result = $conn->query($str) or die($conn->error);
				$str1='SELECT MAX(id) FROM  hp';	
				$result1 = $conn->query($str1) or die($conn->error);
				$data1 = $result1->fetch_array(MYSQLI_ASSOC);
				$k=$data1['MAX(id)'];
				while($i<=$count)
				{	
					$detail='detail'.$i;
					$detail = $conn->real_escape_string(strip_tags(trim($_REQUEST[$detail])));
					$str="update hp set `detail{$i}`='$detail'  where id='$k'";
					$result = $conn->query($str) or die($conn->error);
					$i++;
				}
			}
			elseif ($j==4) {
				$str="insert into dell (name,price,image) values ('$name','$price','$img')";
				$result = $conn->query($str) or die($conn->error);
				$str1='SELECT MAX(id) FROM dell';	
				$result1 = $conn->query($str1) or die($conn->error);
				$data1 = $result1->fetch_array(MYSQLI_ASSOC);
				$k=$data1['MAX(id)'];
				while($i<=$count)
				{	
					$detail='detail'.$i;
					$detail = $conn->real_escape_string(strip_tags(trim($_REQUEST[$detail])));
					$str="update dell set `detail{$i}`='$detail'  where id='$k'";
					$result = $conn->query($str) or die($conn->error);
					$i++;
				}
			}
			elseif($j==5){
				$str="insert into microsoft  (name,price,image) values ('$name','$price','$img')";
				$result = $conn->query($str) or die($conn->error);
				$str1='SELECT MAX(id) FROM Asus';	
				$result1 = $conn->query($str1) or die($conn->error);
				$data1 = $result1->fetch_array(MYSQLI_ASSOC);
				$k=$data1['MAX(id)'];
				while($i<=$count)
				{	
					$detail='detail'.$i;
					$detail = $conn->real_escape_string(strip_tags(trim($_REQUEST[$detail])));
					$str="update Asus set `detail{$i}`='$detail'  where id='$k'";
					$result = $conn->query($str) or die($conn->error);
					$i++;
				}
			}
			elseif($j==6){
				$str="insert into apple (name,price,image) values ('$name','$price','$img') ";
				$result = $conn->query($str) or die($conn->error);
				$str1='SELECT MAX(id) FROM apple';	
				$result1 = $conn->query($str1) or die($conn->error);
				$data1 = $result1->fetch_array(MYSQLI_ASSOC);
				$k=$data1['MAX(id)'];
				while($i<=$count)
				{	
					$detail='detail'.$i;
					$detail = $conn->real_escape_string(strip_tags(trim($_REQUEST[$detail])));
					$str="update apple set `detail{$i}`='$detail'  where id='$k'";
					$result = $conn->query($str) or die($conn->error);
					$i++;
				}
			}
			elseif($j==7){
				$str="insert into lenovo  (name,price,image) values ('$name','$price','$img')";
				$result = $conn->query($str) or die($conn->error);
				$str1='SELECT MAX(id) FROM Lenovo';	
				$result1 = $conn->query($str1) or die($conn->error);
				$data1 = $result1->fetch_array(MYSQLI_ASSOC);
				$k=$data1['MAX(id)'];
				while($i<=$count)
				{	
					$detail='detail'.$i;
					$detail = $conn->real_escape_string(strip_tags(trim($_REQUEST[$detail])));
					$str="update Lenovo set `detail{$i}`='$detail'  where id='$k'";
					$result = $conn->query($str) or die($conn->error);
					$i++;
				}
			}
			elseif($j==9){
				$str="insert into components (name,price,image) values ('$name','$price','$img')";
				$result = $conn->query($str) or die($conn->error);
				$str1='SELECT MAX(id) FROM components';	
				$result1 = $conn->query($str1) or die($conn->error);
				$data1 = $result1->fetch_array(MYSQLI_ASSOC);
				$k=$data1['MAX(id)'];
				while($i<=$count)
				{	
					$detail='detail'.$i;
					$detail = $conn->real_escape_string(strip_tags(trim($_REQUEST[$detail])));
					$str="update components set `detail{$i}`='$detail'  where id='$k'";
					$result = $conn->query($str) or die($conn->error);
					$i++;
				}
			}
			elseif($j==10){
				$str="insert into bags  (name,price,image) values ('$name','$price','$img')";
				$result = $conn->query($str) or die($conn->error);
				$str1='SELECT MAX(id) FROM bags';	
				$result1 = $conn->query($str1) or die($conn->error);
				$data1 = $result1->fetch_array(MYSQLI_ASSOC);
				$k=$data1['MAX(id)'];
				while($i<=$count)
				{	
					$detail='detail'.$i;
					$detail = $conn->real_escape_string(strip_tags(trim($_REQUEST[$detail])));
					$str="update bags set `detail{$i}`='$detail'  where id='$k'";
					$result = $conn->query($str) or die($conn->error);
					$i++;
				}
			}
			elseif($j==11){
				$str="insert into networkcomponents (name,price,image) values ('$name','$price','$img')";
				$result = $conn->query($str) or die($conn->error);
				$str1='SELECT MAX(id) FROM networkcomponents';	
				$result1 = $conn->query($str1) or die($conn->error);
				$data1 = $result1->fetch_array(MYSQLI_ASSOC);
				$k=$data1['MAX(id)'];
				while($i<=$count)
				{	
					$detail='detail'.$i;
					$detail = $conn->real_escape_string(strip_tags(trim($_REQUEST[$detail])));
					$str="update networkcomponents set `detail{$i}`='$detail'  where id='$k'";
					$result = $conn->query($str) or die($conn->error);
					$i++;
				}
			}
			elseif($j==1){
				$str="insert into bestsellers  (name,price,image) values ('$name','$price','$img')";
				$result = $conn->query($str) or die($conn->error);
				$str1='SELECT MAX(id) FROM bestsellers';	
				$result1 = $conn->query($str1) or die($conn->error);
				$data1 = $result1->fetch_array(MYSQLI_ASSOC);
				$k=$data1['MAX(id)'];
				while($i<=$count)
				{	
					$detail='detail'.$i;
					$detail = $conn->real_escape_string(strip_tags(trim($_REQUEST[$detail])));
					$str="update bestsellers set `detail{$i}`='$detail'  where id='$k'";
					$result = $conn->query($str) or die($conn->error);
					$i++;
				}
			}
			elseif($j==2){
				$str="insert into newreleases values (name,price,image) values ('$name','$price','$img')";
				$result = $conn->query($str) or die($conn->error);
				$str1='SELECT MAX(id) FROM newreleases';	
				$result1 = $conn->query($str1) or die($conn->error);
				$data1 = $result1->fetch_array(MYSQLI_ASSOC);
				$k=$data1['MAX(id)'];
				while($i<=$count)
				{	
					$detail='detail'.$i;
					$detail = $conn->real_escape_string(strip_tags(trim($_REQUEST[$detail])));
					$str="update newreleases set `detail{$i}`='$detail'  where id='$k'";
					$result = $conn->query($str) or die($conn->error);
					$i++;
				}
			}
		




		
		
		$str= "insert into search(name,j,k) values ('$name','$j','$k')";
		$result = $conn->query($str) or die($conn->error);

		$str="create table `{$j}{$k}`(comment varchar(100),date varchar(20),id varchar(20))";
		$result=$conn->query($str) or die($conn->error);


		 unset($_SESSION['href']);
	     header("location:search.php?href=$j");	
?>


